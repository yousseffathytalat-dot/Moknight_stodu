#!/usr/bin/env bash
set -euo pipefail

# Download upstream source at build time; it is not copied into the project ZIP.
TARGET="app/src/main/cpp/llama.cpp"
REPO="https://github.com/ggml-org/llama.cpp.git"

mkdir -p app/src/main/cpp
if [ -d "$TARGET/.git" ]; then
  git -C "$TARGET" fetch --depth 1 origin master
  git -C "$TARGET" reset --hard FETCH_HEAD
else
  rm -rf "$TARGET"
  git clone --depth 1 --branch master "$REPO" "$TARGET"
fi

test -f "$TARGET/CMakeLists.txt"
test -f "$TARGET/include/llama.h"
echo "llama.cpp source ready for Android NDK/CMake build."
