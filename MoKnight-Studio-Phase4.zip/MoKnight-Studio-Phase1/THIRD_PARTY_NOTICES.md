# Third-party notices

- **llama.cpp** — fetched from https://github.com/ggml-org/llama.cpp at build time. The upstream project is distributed under the MIT License; the exact upstream license file is included in the fetched source used by the build.
- **Qwen2.5-Coder-0.5B-Instruct-GGUF** — downloaded by the user inside the app from https://huggingface.co/Qwen/Qwen2.5-Coder-0.5B-Instruct-GGUF. The model repository identifies its license as Apache-2.0. The model is not bundled in this source ZIP or the APK.

Review the upstream repositories and their license files for the full legal terms before distributing builds.
