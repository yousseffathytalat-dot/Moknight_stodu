package com.moknight.studio

object LocalLlama {
    init {
        System.loadLibrary("moknight_llama")
    }

    /** Returns the model output as UTF-8 bytes (safe for Arabic / emoji). */
    external fun generateNative(modelPath: String, prompt: String, maxTokens: Int): ByteArray

    /** Asks a running generation to stop as soon as possible. */
    external fun cancelNative()
}
