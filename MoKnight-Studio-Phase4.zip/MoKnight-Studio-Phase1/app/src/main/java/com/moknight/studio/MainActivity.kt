package com.moknight.studio

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("moknight_model", Context.MODE_PRIVATE) }
    private val downloadManager by lazy { getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }
    private var polling = false

    // Models downloaded by older builds lived in internal storage; keep using them if present.
    private val legacyModelFile: File by lazy { File(File(filesDir, "models"), MODEL_NAME) }

    private fun externalModelFile(): File? {
        val base = getExternalFilesDir(null) ?: return null
        val dir = File(base, "models")
        dir.mkdirs()
        return File(dir, MODEL_NAME)
    }

    /** The model file that is fully downloaded and usable, or null. */
    private fun activeModelFile(): File? {
        if (legacyModelFile.exists() && legacyModelFile.length() > MIN_MODEL_BYTES) return legacyModelFile
        val ext = externalModelFile() ?: return null
        if (prefs.getBoolean(KEY_DONE, false) && ext.exists() && ext.length() > MIN_MODEL_BYTES) return ext
        return null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.editorWebView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Once the editor is loaded: report the model state, or start the automatic download.
                if (activeModelFile() != null) js("onModelReady()") else startModelDownload()
            }
        }
        webView.addJavascriptInterface(EditorBridge(), "MoKnight")
        webView.loadUrl("file:///android_asset/editor/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("(window.MoKnightEditor ? window.MoKnightEditor.handleBack() : false)") { result ->
                    if (result != "true") finish()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (activeModelFile() == null && prefs.getLong(KEY_ID, -1L) != -1L) startPolling()
    }

    override fun onPause() {
        stopPolling()
        super.onPause()
    }

    private fun js(functionCall: String) {
        runOnUiThread {
            webView.evaluateJavascript("window.MoKnightEditor && window.MoKnightEditor.$functionCall", null)
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Automatic model download (Android DownloadManager)                  */
    /*  Keeps going in the background, resumes after network loss, and      */
    /*  shows a system notification.                                        */
    /* ------------------------------------------------------------------ */
    private data class DlState(val status: Int, val done: Long, val total: Long, val reason: Int)

    private fun queryDownload(id: Long): DlState? {
        downloadManager.query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (!c.moveToFirst()) return null
            return DlState(
                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            )
        }
        return null
    }

    private fun reportError(message: String) {
        js("onModelError(" + JSONObject.quote(message) + ")")
    }

    private fun startModelDownload() {
        if (activeModelFile() != null) {
            js("onModelReady()")
            return
        }
        val target = externalModelFile()
        if (target == null) {
            reportError("Storage is not available on this device.")
            return
        }
        val savedId = prefs.getLong(KEY_ID, -1L)
        if (savedId != -1L) {
            val state = queryDownload(savedId)
            if (state != null) {
                when (state.status) {
                    DownloadManager.STATUS_RUNNING,
                    DownloadManager.STATUS_PENDING,
                    DownloadManager.STATUS_PAUSED -> {
                        startPolling()
                        return
                    }
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        finishDownload(savedId, target)
                        return
                    }
                }
            }
            downloadManager.remove(savedId)
            prefs.edit().remove(KEY_ID).apply()
        }
        if (target.exists()) target.delete()
        try {
            val request = DownloadManager.Request(Uri.parse(MODEL_URL))
                .setTitle("MoKnight Studio - offline AI model")
                .setDescription("Qwen2.5-Coder 0.5B (about 491 MB)")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(target))
                .addRequestHeader("User-Agent", "MoKnightStudio-Android")
            val id = downloadManager.enqueue(request)
            prefs.edit().putLong(KEY_ID, id).putBoolean(KEY_DONE, false).apply()
            js("onModelProgress(0, 'Starting download…')")
            startPolling()
        } catch (e: Exception) {
            reportError(e.message ?: "Could not start the download.")
        }
    }

    private fun finishDownload(id: Long, target: File) {
        if (target.exists() && target.length() > MIN_MODEL_BYTES) {
            prefs.edit().putBoolean(KEY_DONE, true).remove(KEY_ID).apply()
            js("onModelReady()")
        } else {
            downloadManager.remove(id)
            prefs.edit().remove(KEY_ID).putBoolean(KEY_DONE, false).apply()
            if (target.exists()) target.delete()
            reportError("The downloaded file is incomplete. Please retry.")
        }
    }

    private fun describeFailure(reason: Int): String = when (reason) {
        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Not enough free storage (about 1 GB needed)."
        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "Storage is not available."
        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "The model server redirected too many times."
        else -> "Download failed (code $reason). Check your connection and retry."
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!polling) return
            val id = prefs.getLong(KEY_ID, -1L)
            val target = externalModelFile()
            if (id == -1L || target == null) {
                polling = false
                return
            }
            val state = queryDownload(id)
            if (state == null) {
                polling = false
                prefs.edit().remove(KEY_ID).apply()
                reportError("The download was cancelled.")
                return
            }
            val percent = if (state.total > 0) ((state.done * 100) / state.total).toInt().coerceIn(0, 100) else 0
            when (state.status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    polling = false
                    finishDownload(id, target)
                    return
                }
                DownloadManager.STATUS_FAILED -> {
                    polling = false
                    downloadManager.remove(id)
                    prefs.edit().remove(KEY_ID).apply()
                    reportError(describeFailure(state.reason))
                    return
                }
                DownloadManager.STATUS_PAUSED -> js("onModelProgress($percent, 'Waiting for network…')")
                else -> js("onModelProgress($percent, 'Downloading offline model…')")
            }
            ui.postDelayed(this, 700)
        }
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        ui.post(pollRunnable)
    }

    private fun stopPolling() {
        polling = false
        ui.removeCallbacks(pollRunnable)
    }

    /* ------------------------------------------------------------------ */
    /*  JS bridge                                                           */
    /* ------------------------------------------------------------------ */
    inner class EditorBridge {
        @JavascriptInterface
        fun onDocumentChanged(html: String) {
            // The editor currently keeps the active document in its WebView workspace.
        }

        @JavascriptInterface
        fun getAppVersion(): String = BuildConfig.VERSION_NAME

        @JavascriptInterface
        fun modelReady(): Boolean = activeModelFile() != null

        /** Manual start / retry (the download also starts by itself on launch). */
        @JavascriptInterface
        fun downloadModel() {
            runOnUiThread { startModelDownload() }
        }

        @JavascriptInterface
        fun askLocalAi(prompt: String, maxTokens: Int) {
            val model = activeModelFile()
            if (model == null) {
                js("onAiError('The offline model is not ready yet.')")
                return
            }
            worker.execute {
                try {
                    val bytes = LocalLlama.generateNative(model.absolutePath, prompt, maxTokens.coerceIn(64, 1800))
                    val answer = String(bytes, Charsets.UTF_8)
                    js("onAiResult(" + JSONObject.quote(answer) + ")")
                } catch (e: Throwable) {
                    js("onAiError(" + JSONObject.quote(e.message ?: "Local AI could not start") + ")")
                }
            }
        }

        /** Saves the finished page as a stand-alone .html file in the Downloads folder. */
        @JavascriptInterface
        fun saveHtml(fileName: String, html: String) {
            worker.execute {
                try {
                    val safe = fileName.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "moknight-page.html" }
                    val bytes = html.toByteArray(Charsets.UTF_8)
                    val where: String
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, safe)
                            put(MediaStore.Downloads.MIME_TYPE, "text/html")
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            ?: throw IllegalStateException("Could not create the file")
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                            ?: throw IllegalStateException("Could not write the file")
                        where = "Downloads/$safe"
                    } else {
                        // Android 8/9: no storage permission is requested, so use the app's own documents folder.
                        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
                        dir.mkdirs()
                        val f = File(dir, safe)
                        f.writeBytes(bytes)
                        where = f.absolutePath
                    }
                    js("onHtmlSaved(" + JSONObject.quote(where) + ")")
                } catch (e: Throwable) {
                    js("onHtmlError(" + JSONObject.quote(e.message ?: "unknown error") + ")")
                }
            }
        }

        @JavascriptInterface
        fun cancelAi() {
            try {
                LocalLlama.cancelNative()
            } catch (_: Throwable) {
            }
        }
    }

    override fun onDestroy() {
        stopPolling()
        try {
            LocalLlama.cancelNative()
        } catch (_: Throwable) {
        }
        worker.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val MODEL_NAME = "qwen2.5-coder-0.5b-instruct-q4_k_m.gguf"
        private const val MODEL_URL = "https://huggingface.co/Qwen/Qwen2.5-Coder-0.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-0.5b-instruct-q4_k_m.gguf?download=true"
        private const val MIN_MODEL_BYTES = 300_000_000L
        private const val KEY_ID = "download_id"
        private const val KEY_DONE = "model_done"
    }
}
