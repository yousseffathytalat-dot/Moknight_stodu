(() => {
  'use strict';

  /* ======================================================================
   *  MoKnight Studio — split editor
   *  Source code (left/top)  <—— two-way sync ——>  Live preview (right/bottom)
   *
   *  `source` (a string) is the single source of truth.
   *  - Typing in the code editor  -> source -> preview re-render.
   *  - Editing in the preview     -> parse source, change the DOM node,
   *                                  serialize back -> source -> code editor.
   *  Every element in the preview carries data-mk="<index>", the index being
   *  its position in elementsOf(doc); the same index addresses it in the
   *  parsed source, so the two sides always agree on "which element".
   * ====================================================================== */

  const INITIAL = `<!doctype html>
<html lang="ar">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:linear-gradient(145deg,#11182c,#27345b);font-family:system-ui,sans-serif}
.card{width:min(86%,340px);padding:34px 22px;text-align:center;border:1px solid #ffffff45;border-radius:24px;background:#ffffff18;box-shadow:0 20px 60px #0004;color:white;backdrop-filter:blur(12px)}
h1{font-size:29px;margin:0 0 10px}
p{color:#d5dcf1;margin:0}
</style>
</head>
<body>
<article class="card">
<h1>السلام عليكم</h1>
<p>مرحباً بك في MoKnight Studio</p>
</article>
</body>
</html>`;

  const $ = id => document.getElementById(id);
  const code = $('codeEditor'), frame = $('previewFrame'), saveState = $('saveState');
  const workspace = $('workspace');

  let source = INITIAL;
  let selId = null;          // index of the selected element (null = none)
  let pendingSelect = null;  // select this id once the preview reloads
  let scrollY = 0;
  let renderTimer = null;
  let kfOpen = false, kf = null, kfPrevView = null;   // keyframe editor state

  /* ------------------------------------------------------------------ */
  /*  Effects library (real CSS classes written into the document)       */
  /* ------------------------------------------------------------------ */
  const FX = {
    anim: {
      'mk-fade':   { label: 'Fade in',  css: '@keyframes mkFade{from{opacity:0}to{opacity:1}}\n.mk-fade{animation:mkFade .9s ease both}' },
      'mk-slide':  { label: 'Slide up', css: '@keyframes mkSlide{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:none}}\n.mk-slide{animation:mkSlide .8s cubic-bezier(.2,.8,.2,1) both}' },
      'mk-zoom':   { label: 'Zoom in',  css: '@keyframes mkZoom{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:none}}\n.mk-zoom{animation:mkZoom .7s cubic-bezier(.2,.9,.3,1.2) both}' },
      'mk-bounce': { label: 'Bounce',   css: '@keyframes mkBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-14px)}}\n.mk-bounce{animation:mkBounce 1.1s ease-in-out infinite}' },
      'mk-pulse':  { label: 'Pulse',    css: '@keyframes mkPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}\n.mk-pulse{animation:mkPulse 1.4s ease-in-out infinite}' },
      'mk-shake':  { label: 'Shake',    css: '@keyframes mkShake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-7px)}40%,80%{transform:translateX(7px)}}\n.mk-shake{animation:mkShake .8s ease-in-out infinite}' },
      'mk-float':  { label: 'Float',    css: '@keyframes mkFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}\n.mk-float{animation:mkFloat 3s ease-in-out infinite}' },
      'mk-spin':   { label: 'Spin',     css: '@keyframes mkSpin{to{transform:rotate(360deg)}}\n.mk-spin{animation:mkSpin 3s linear infinite}' }
    },
    look: {
      'mk-shadow':   { label: 'Shadow',      css: '.mk-shadow{box-shadow:0 14px 40px rgba(0,0,0,.35)}' },
      'mk-glow':     { label: 'Glow',        css: '.mk-glow{box-shadow:0 0 28px 4px rgba(124,108,255,.7)}' },
      'mk-neon':     { label: 'Neon text',   css: '.mk-neon{color:#fff;text-shadow:0 0 6px #fff,0 0 14px #7c6cff,0 0 30px #7c6cff}' },
      'mk-gradtext': { label: 'Gradient text', css: '.mk-gradtext{background:linear-gradient(90deg,#a99dff,#64d9e9);-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent}' },
      'mk-glass':    { label: 'Glass',       css: '.mk-glass{background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.28);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px)}' },
      'mk-lift':     { label: 'Hover lift',  css: '.mk-lift{transition:transform .25s,box-shadow .25s}\n.mk-lift:hover{transform:translateY(-6px) scale(1.03);box-shadow:0 18px 40px rgba(0,0,0,.35)}' }
    }
  };
  const ALL_FX = Object.assign({}, FX.anim, FX.look);

  /* ------------------------------------------------------------------ */
  /*  Document helpers                                                    */
  /* ------------------------------------------------------------------ */
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE']);
  const parse = src => new DOMParser().parseFromString(src, 'text/html');

  // body = index 0, then every element inside it (ignoring script/style/svg internals)
  function elementsOf(doc) {
    const out = [doc.body];
    doc.body.querySelectorAll('*').forEach(el => {
      if (SKIP.has(el.tagName)) return;
      if (el.parentElement && el.parentElement.closest('svg')) return;
      out.push(el);
    });
    return out;
  }

  function serialize(doc) {
    const dt = /^\s*<!doctype[^>]*>/i.exec(source);
    return (dt ? dt[0].trim() : '<!doctype html>') + '\n' + doc.documentElement.outerHTML;
  }

  function buildPreview() {
    const doc = parse(source);
    elementsOf(doc).forEach((el, i) => el.setAttribute('data-mk', i));
    const s = doc.createElement('script');
    s.textContent = '(' + frameMain.toString() + ')()';
    doc.body.appendChild(s);
    return '<!doctype html>\n' + doc.documentElement.outerHTML;
  }

  function renderPreview() {
    frame.srcdoc = buildPreview();
  }

  /* ------------------------------------------------------------------ */
  /*  Script that runs INSIDE the preview iframe                          */
  /* ------------------------------------------------------------------ */
  function frameMain() {
    var send = function (m) { m.mk = 1; parent.postMessage(m, '*'); };
    var st = document.createElement('style');
    st.textContent =
      '[data-mk]:hover{outline:1px dashed rgba(124,108,255,.75);outline-offset:1px}' +
      'html.mk-live [data-mk]:hover{outline:none}html.mk-live [data-mk-sel]{outline:none!important}' +
      '[data-mk-sel]{outline:2px solid #7c6cff!important;outline-offset:2px}' +
      '[contenteditable="true"]{outline:2px solid #2fd6a0!important;outline-offset:2px;cursor:text;-webkit-user-select:text;user-select:text}';
    document.head.appendChild(st);

    var sel = null, editing = null, live = false;
    var kfReset = function (el) { el.style.animationName = 'none'; void el.offsetWidth; el.style.animationName = ''; };
    var rgb2hex = function (c) {
      var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(c || '');
      if (!m || (m[4] !== undefined && parseFloat(m[4]) === 0)) return '';
      return '#' + [m[1], m[2], m[3]].map(function (n) { return ('0' + (+n).toString(16)).slice(-2); }).join('');
    };
    var clean = function (el) {
      var c = el.cloneNode(true);
      [c].concat([].slice.call(c.querySelectorAll('*'))).forEach(function (n) {
        n.removeAttribute('data-mk'); n.removeAttribute('data-mk-sel'); n.removeAttribute('contenteditable');
        if (n.classList && n.classList.contains('mkk-go')) { n.classList.remove('mkk-go'); if (!n.getAttribute('class')) n.removeAttribute('class'); }
        if (n.style) {   // never leak the keyframe-preview helpers into the saved source
          n.style.removeProperty('animation-play-state'); n.style.removeProperty('animation-delay'); n.style.removeProperty('animation-name');
          n.style.removeProperty('animation-direction'); n.style.removeProperty('animation-iteration-count');
          if (n.getAttribute('style') === '') n.removeAttribute('style');
        }
      });
      return c.innerHTML;
    };
    var id = function (el) { return +el.getAttribute('data-mk'); };

    function info(el) {
      var cs = getComputedStyle(el);
      return {
        tag: el.tagName.toLowerCase(),
        classes: (el.getAttribute('class') || '').split(/\s+/).filter(Boolean),
        text: el.children.length ? null : el.textContent,
        src: el.tagName === 'IMG' ? el.getAttribute('src') || '' : null,
        href: el.tagName === 'A' ? el.getAttribute('href') || '' : null,
        color: rgb2hex(cs.color),
        bg: rgb2hex(cs.backgroundColor),
        size: parseFloat(cs.fontSize) || 16,
        weight: cs.fontWeight,
        align: cs.textAlign,
        radius: parseFloat(cs.borderTopLeftRadius) || 0,
        pad: parseFloat(cs.paddingTop) || 0,
        opacity: Math.round((parseFloat(cs.opacity) || 1) * 100),
        width: Math.round(el.getBoundingClientRect().width), height: Math.round(el.getBoundingClientRect().height),
        margin: parseFloat(cs.marginTop) || 0, borderW: parseFloat(cs.borderTopWidth) || 0, borderC: rgb2hex(cs.borderTopColor),
        ls: parseFloat(cs.letterSpacing) || 0, lh: cs.lineHeight === 'normal' ? 1.4 : Math.round(parseFloat(cs.lineHeight) / (parseFloat(cs.fontSize) || 16) * 100) / 100,
        gap: parseFloat(cs.gap) || 0, display: cs.display
      };
    }
    function endEdit() {
      if (!editing) return;
      editing.removeAttribute('contenteditable');
      editing = null;
      send({ type: 'editEnd' });
    }
    function select(el) {
      endEdit();
      if (sel) sel.removeAttribute('data-mk-sel');
      sel = el;
      if (!el) { send({ type: 'select', id: null }); return; }
      el.setAttribute('data-mk-sel', '');
      send({ type: 'select', id: id(el), info: info(el) });
    }
    function startEdit(el, e) {
      if (el.tagName === 'IMG' || el.tagName === 'BODY' || el.tagName === 'HR') return;
      el.setAttribute('contenteditable', 'true');
      editing = el;
      el.focus();
      try {
        var r = document.caretRangeFromPoint ? document.caretRangeFromPoint(e.clientX, e.clientY) : null;
        if (r) { var s = getSelection(); s.removeAllRanges(); s.addRange(r); }
      } catch (_) {}
      send({ type: 'editStart' });
    }

    document.addEventListener('click', function (e) {
      if (live) return;                                            // Run mode: the page behaves like the real thing
      if (editing && editing.contains(e.target)) return;          // caret placement while typing
      e.preventDefault(); e.stopPropagation();
      var el = e.target.closest ? e.target.closest('[data-mk]') : null;
      if (!el) { select(null); return; }
      if (el === sel && !editing) startEdit(el, e); else select(el);
    }, true);
    document.addEventListener('submit', function (e) { e.preventDefault(); }, true);

    document.addEventListener('input', function () {
      if (editing) send({ type: 'text', id: id(editing), html: clean(editing) });
    });
    document.addEventListener('keydown', function (e) {
      if (!editing) return;
      if (e.key === 'Escape') { endEdit(); }
      else if (e.key === 'Enter' && !e.shiftKey && !/^(P|DIV|ARTICLE|SECTION|LI)$/.test(editing.tagName)) { e.preventDefault(); endEdit(); }
    }, true);
    document.addEventListener('paste', function (e) {
      if (!editing) return;
      e.preventDefault();
      var t = (e.clipboardData || window.clipboardData).getData('text/plain');
      document.execCommand('insertText', false, t);
    });
    document.addEventListener('focusout', function () { setTimeout(function () { if (editing && document.activeElement !== editing) endEdit(); }, 60); });

    var st2 = null;
    window.addEventListener('scroll', function () {
      clearTimeout(st2); st2 = setTimeout(function () { send({ type: 'scroll', y: window.scrollY }); }, 120);
    });

    window.addEventListener('message', function (e) {
      var m = e.data; if (!m || !m.mk) return;
      var el = m.id != null ? document.querySelector('[data-mk="' + m.id + '"]') : null;
      if (m.type === 'select') { select(el); if (el && m.reveal) el.scrollIntoView({ block: 'nearest' }); }
      else if (m.type === 'deselect') select(null);
      else if (m.type === 'style' && el) { if (m.value === '') el.style.removeProperty(m.prop); else el.style.setProperty(m.prop, m.value); }
      else if (m.type === 'text' && el && el !== editing) { el.textContent = m.text; }
      else if (m.type === 'attr' && el) { if (m.remove) el.removeAttribute(m.name); else el.setAttribute(m.name, m.value); }
      else if (m.type === 'live') { live = !!m.on; document.documentElement.classList.toggle('mk-live', live); if (live) select(null); }
      else if (m.type === 'scroll') window.scrollTo(0, m.y);
      else if (m.type === 'kfcss') {
        var kt = document.getElementById('mk-keyframes');
        if (!kt) { kt = document.createElement('style'); kt.id = 'mk-keyframes'; document.head.appendChild(kt); }
        kt.textContent = m.css;
      }
      else if (m.type === 'kfscrub' && el) {
        // show the animation frozen at time m.t (restart first so the held time is exactly 0, then offset with a negative delay)
        el.classList.add('mkk-go'); kfReset(el);
        el.style.animationPlayState = 'paused'; el.style.animationDelay = (-m.t) + 's';
        el.style.animationDirection = 'normal'; el.style.animationIterationCount = '1';
      }
      else if (m.type === 'kfplay' && el) {
        el.classList.add('mkk-go'); kfReset(el);
        el.style.animationPlayState = ''; el.style.animationIterationCount = '';
        el.style.animationDirection = m.from > 0 ? 'normal' : '';
        el.style.animationDelay = m.from > 0 ? (-m.from) + 's' : '';
      }
      else if (m.type === 'kfidle' && el) {
        el.classList.remove('mkk-go');
        el.style.animationPlayState = ''; el.style.animationDelay = ''; el.style.animationDirection = ''; el.style.animationIterationCount = '';
        kfReset(el);
      }
    });

    window.addEventListener('load', function () { send({ type: 'ready' }); });
  }

  /* ------------------------------------------------------------------ */
  /*  Run mode: the preview behaves like the finished page (taps trigger  */
  /*  animations instead of selecting elements)                           */
  /* ------------------------------------------------------------------ */
  let live = false;
  const runBtn = $('runBtn');
  function setLive(on) {
    live = on;
    runBtn.classList.toggle('on', on);
    runBtn.textContent = on ? '■ Stop' : '▶ Run';
    $('previewHint').textContent = on ? 'Run mode — tap your buttons to test the animations' : 'Tap an element · tap again to type';
    if (on) { selId = null; pendingSelect = null; if (kfOpen) closeKf(); insp.classList.add('hidden'); }
    renderPreview();            // fresh page either way, so every animation starts from its first state
  }
  runBtn.onclick = () => setLive(!live);

  /* ------------------------------------------------------------------ */
  /*  Download the finished page as a stand-alone .html file              */
  /* ------------------------------------------------------------------ */
  function exportName() {
    const m = /<title[^>]*>([^<]*)<\/title>/i.exec(source);
    const base = ((m && m[1]) || 'moknight-page').trim().replace(/[^\w\u0600-\u06FF .-]+/g, '').replace(/\s+/g, '-').slice(0, 40);
    return (base || 'moknight-page') + '.html';
  }
  $('dlBtn').onclick = () => {
    const file = exportName();
    if (window.MoKnight && MoKnight.saveHtml) { MoKnight.saveHtml(file, source); return; }
    try {                                            // desktop / browser fallback
      const url = URL.createObjectURL(new Blob([source], { type: 'text/html;charset=utf-8' }));
      const a = document.createElement('a');
      a.href = url; a.download = file;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      flash('✓ Downloaded ' + file, 3500);
    } catch (_) { flash('Download failed'); }
  };

  /* ------------------------------------------------------------------ */
  /*  History (undo / redo)                                               */
  /* ------------------------------------------------------------------ */
  const undoStack = [], redoStack = [];
  let lastKey = null, lastTime = 0;
  const undoBtn = $('undoBtn'), redoBtn = $('redoBtn');
  function syncHistoryButtons() { undoBtn.disabled = !undoStack.length; redoBtn.disabled = !redoStack.length; }
  function pushHistory(key) {
    const now = Date.now();
    if (key && key === lastKey && now - lastTime < 1200) { lastTime = now; return; }
    undoStack.push(source); if (undoStack.length > 100) undoStack.shift();
    redoStack.length = 0;
    lastKey = key || null; lastTime = now;
    syncHistoryButtons();
  }
  function restore(src) {
    source = src; setCode(source); lastKey = null;
    selId = null; hideInspector(); renderPreview(); notify(); syncHistoryButtons();
    flash('Synced');
  }
  undoBtn.onclick = () => { if (!undoStack.length) return; redoStack.push(source); restore(undoStack.pop()); };
  redoBtn.onclick = () => { if (!redoStack.length) return; undoStack.push(source); restore(redoStack.pop()); };

  /* ------------------------------------------------------------------ */
  /*  Syncing                                                             */
  /* ------------------------------------------------------------------ */
  let flashTimer;
  function flash(msg, ms) {
    saveState.textContent = msg;
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => { saveState.textContent = 'Synced locally'; }, ms || 1400);
  }
  function notify() { if (window.MoKnight && MoKnight.onDocumentChanged) MoKnight.onDocumentChanged(source); }
  function setCode(text) {
    if (code.value === text) return;
    const top = code.scrollTop, left = code.scrollLeft;
    code.value = text;
    code.scrollTop = top; code.scrollLeft = left;
  }
  function post(msg) { try { frame.contentWindow.postMessage(Object.assign({ mk: 1 }, msg), '*'); } catch (_) {} }

  /**
   * Change the document through its DOM.
   * fn(doc, list) may return false (abort) or { select: Node } .
   * opts.key      coalesces rapid edits into a single undo step
   * opts.render   re-render the preview (needed for structural changes)
   */
  function mutate(fn, opts = {}) {
    const doc = parse(source);
    const list = elementsOf(doc);
    const res = fn(doc, list);
    if (res === false) return;
    const selIndex = res && res.select ? elementsOf(doc).indexOf(res.select) : -1;
    const next = serialize(doc);
    if (next === source) return;
    pushHistory(opts.key);
    source = next;
    setCode(source);
    notify();
    flash('Synced');
    if (opts.render) {
      if (res && res.select) pendingSelect = selIndex;
      else pendingSelect = res && res.select === null ? null : (opts.keepSelection ? selId : null);
      renderPreview();
    }
  }

  /* code -> preview */
  code.addEventListener('input', () => {
    saveState.textContent = 'Editing…';
    clearTimeout(renderTimer);
    renderTimer = setTimeout(() => {
      pushHistory('code');
      source = code.value;
      selId = null; pendingSelect = null; hideInspector();
      renderPreview(); notify(); flash('Preview updated');
    }, 260);
  });
  code.addEventListener('keydown', e => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = code.selectionStart, t = code.selectionEnd;
      code.setRangeText('  ', s, t, 'end');
      code.dispatchEvent(new Event('input'));
    }
  });

  /* preview -> code */
  window.addEventListener('message', e => {
    const m = e.data;
    if (e.source !== frame.contentWindow || !m || !m.mk) return;
    switch (m.type) {
      case 'ready':
        if (scrollY) post({ type: 'scroll', y: scrollY });
        if (pendingSelect != null) post({ type: 'select', id: pendingSelect, reveal: true });
        pendingSelect = null;
        if (live) post({ type: 'live', on: true });
        if (kfOpen && kf && kf.scrubbed) kfScrubPost();
        break;
      case 'scroll': scrollY = m.y; break;
      case 'select':
        if (kfOpen && kf && kf.pick && m.id != null) { kfPicked(m.id); break; }
        selId = m.id;
        if (m.id == null) hideInspector();
        else {
          showInspector(m.info);
          if (kfOpen) { insp.classList.add('hidden'); if (!kf || kf.elId !== m.id) openKfPanel(); }
        }
        break;
      case 'editStart': $('previewHint').textContent = 'Typing… (Esc / tap outside to finish)'; break;
      case 'editEnd': $('previewHint').textContent = 'Tap an element · tap again to type'; break;
      case 'text':
        mutate((doc, list) => {
          const el = list[m.id]; if (!el) return false;
          el.innerHTML = m.html;
        }, { key: 'type' });
        break;
    }
  });

  /* ------------------------------------------------------------------ */
  /*  Inspector                                                           */
  /* ------------------------------------------------------------------ */
  const insp = $('inspector');
  const inp = {
    text: $('inText'), src: $('inSrc'), href: $('inHref'), color: $('inColor'), bg: $('inBg'),
    size: $('inSize'), weight: $('inWeight'), radius: $('inRadius'), pad: $('inPad'), opacity: $('inOpacity')
  };
  const out = { size: $('outSize'), radius: $('outRadius'), pad: $('outPad'), opacity: $('outOpacity') };
  let currentClasses = [];

  function hideInspector() { insp.classList.add('hidden'); if (kfOpen) closeKf(); }
  function showInspector(i) {
    insp.classList.remove('hidden');
    $('inspTag').textContent = '<' + i.tag + '>';
    $('fText').classList.toggle('hidden', i.text === null);
    $('fSrc').classList.toggle('hidden', i.src === null);
    $('fHref').classList.toggle('hidden', i.href === null);
    if (i.text !== null && document.activeElement !== inp.text) inp.text.value = i.text.replace(/\s+/g, ' ').trim();
    if (i.src !== null) inp.src.value = i.src;
    if (i.href !== null) inp.href.value = i.href;
    inp.color.value = i.color || '#000000';
    inp.bg.value = i.bg || '#ffffff';
    inp.size.value = i.size; out.size.textContent = Math.round(i.size) + 'px';
    inp.radius.value = i.radius; out.radius.textContent = Math.round(i.radius) + 'px';
    inp.pad.value = i.pad; out.pad.textContent = Math.round(i.pad) + 'px';
    inp.opacity.value = i.opacity; out.opacity.textContent = i.opacity + '%';
    const w = String(i.weight);
    inp.weight.value = ['300', '400', '500', '700', '900'].includes(w) ? w : (+w >= 700 ? '700' : '400');
    document.querySelectorAll('#inAlign button').forEach(b => {
      const a = i.align === 'start' ? 'left' : i.align === 'end' ? 'right' : i.align;
      b.classList.toggle('on', b.dataset.align === a);
    });
    MORE.forEach(m => { if (document.activeElement !== m.el) m.el.value = m.get(i); });
    currentClasses = i.classes;
    $('openKf').textContent = i.classes.some(c => /^mkk-\d+$/.test(c)) ? '🎞 Edit keyframe animation' : '🎞 Keyframe animation';
    paintChips();
  }

  function applyStyle(prop, value, key) {
    if (selId == null) return;
    post({ type: 'style', id: selId, prop, value });
    const id = selId;
    mutate((doc, list) => {
      const el = list[id]; if (!el) return false;
      if (value === '') el.style.removeProperty(prop); else el.style.setProperty(prop, value);
      if (!el.getAttribute('style')) el.removeAttribute('style');
    }, { key: key || ('s:' + prop) });
  }

  /* extra controls: every field writes a real inline style; × removes it */
  const MORE = [
    { id: 'mWidth', prop: 'width', unit: 'px', get: i => i.width },
    { id: 'mHeight', prop: 'height', unit: 'px', get: i => i.height },
    { id: 'mMargin', prop: 'margin', unit: 'px', get: i => i.margin },
    { id: 'mBorderW', prop: 'border-width', unit: 'px', get: i => i.borderW, extra: { 'border-style': 'solid' } },
    { id: 'mLs', prop: 'letter-spacing', unit: 'px', get: i => i.ls },
    { id: 'mLh', prop: 'line-height', unit: '', get: i => i.lh },
    { id: 'mGap', prop: 'gap', unit: 'px', get: i => i.gap, extra: { display: 'flex', 'flex-wrap': 'wrap' } },
    { id: 'mShadow', prop: 'box-shadow', unit: '', get: () => 0, fmt: v => +v ? '0 ' + Math.round(v / 3) + 'px ' + v + 'px rgba(0,0,0,.4)' : '' },
    { id: 'mBlurBg', prop: 'backdrop-filter', unit: '', get: () => 0, fmt: v => +v ? 'blur(' + v + 'px)' : '', extra: { '-webkit-backdrop-filter': null } }
  ];
  MORE.forEach(m => {
    m.el = $(m.id);
    m.el.addEventListener('input', () => {
      if (m.el.value === '') return;
      const v = m.fmt ? m.fmt(m.el.value) : m.el.value + m.unit;
      applyStyle(m.prop, v);
      if (m.extra) Object.keys(m.extra).forEach(k => applyStyle(k, m.extra[k] === null ? v : m.extra[k], 's:' + k));
    });
  });
  $('mBorderC').addEventListener('input', e => { applyStyle('border-color', e.target.value); applyStyle('border-style', 'solid', 's:bs'); if (!+$('mBorderW').value) { $('mBorderW').value = 2; applyStyle('border-width', '2px', 's:bw'); } });
  $('mFont').addEventListener('change', e => applyStyle('font-family', e.target.value));
  $('mDisplay').addEventListener('change', e => applyStyle('display', e.target.value));
  document.querySelectorAll('[data-clear2]').forEach(b => b.addEventListener('click', () => {
    const m = MORE.find(x => x.id === b.dataset.clear2);
    (m ? [m.prop].concat(m.extra ? Object.keys(m.extra) : []) : b.dataset.clear2.split(',')).forEach(pr => applyStyle(pr, ''));
  }));
  $('mHide').addEventListener('click', () => {
    const on = $('mHide').classList.toggle('on');
    applyStyle('display', on ? 'none' : '');
    flash(on ? 'Hidden — select its parent to bring it back' : 'Visible');
  });

  const bindRange = (el, outEl, prop, unit, fmt) => el.addEventListener('input', () => {
    outEl.textContent = el.value + (unit || '');
    applyStyle(prop, fmt ? fmt(el.value) : el.value + (unit || ''));
  });
  bindRange(inp.size, out.size, 'font-size', 'px');
  bindRange(inp.radius, out.radius, 'border-radius', 'px');
  bindRange(inp.pad, out.pad, 'padding', 'px');
  bindRange(inp.opacity, out.opacity, 'opacity', '%', v => String(v / 100));
  inp.color.addEventListener('input', () => applyStyle('color', inp.color.value));
  inp.bg.addEventListener('input', () => applyStyle('background', inp.bg.value));
  inp.weight.addEventListener('change', () => applyStyle('font-weight', inp.weight.value));
  document.querySelectorAll('#inAlign button').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('#inAlign button').forEach(x => x.classList.toggle('on', x === b));
    applyStyle('text-align', b.dataset.align);
  }));
  document.querySelectorAll('[data-clear]').forEach(b => b.addEventListener('click', () => applyStyle(b.dataset.clear, '')));

  inp.text.addEventListener('input', () => {
    if (selId == null) return;
    const id = selId, text = inp.text.value;
    post({ type: 'text', id, text });
    mutate((doc, list) => { const el = list[id]; if (!el || el.children.length) return false; el.textContent = text; }, { key: 'inspText' });
  });
  const bindAttr = (el, name) => el.addEventListener('input', () => {
    if (selId == null) return;
    const id = selId, v = el.value;
    post({ type: 'attr', id, name, value: v });
    mutate((doc, list) => { const t = list[id]; if (!t) return false; t.setAttribute(name, v); }, { key: 'attr:' + name });
  });
  bindAttr(inp.src, 'src'); bindAttr(inp.href, 'href');

  /* effects */
  function paintChips() {
    [['fxAnim', FX.anim, true], ['fxLook', FX.look, false]].forEach(([id, group, exclusive]) => {
      const box = $(id); box.textContent = '';
      if (exclusive) box.appendChild(chip('None', !Object.keys(group).some(c => currentClasses.includes(c)), () => setFx(null, group)));
      Object.keys(group).forEach(cls => box.appendChild(chip(group[cls].label, currentClasses.includes(cls), () => setFx(cls, exclusive ? group : null))));
    });
  }
  function chip(label, on, fn) {
    const b = document.createElement('button');
    b.textContent = label; if (on) b.className = 'on'; b.onclick = fn; return b;
  }
  function setFx(cls, exclusiveGroup) {
    if (selId == null) return;
    const id = selId;
    mutate((doc, list) => {
      const el = list[id]; if (!el) return false;
      const has = cls && el.classList.contains(cls);
      if (exclusiveGroup) Object.keys(exclusiveGroup).forEach(c => el.classList.remove(c));
      if (exclusiveGroup === FX.anim) dropKfClass(doc, el);   // a preset replaces keyframes
      if (cls && !has) el.classList.add(cls);
      if (!exclusiveGroup && cls && has) el.classList.remove(cls);
      if (!el.getAttribute('class')) el.removeAttribute('class');
      syncEffectsStyle(doc);
    }, { render: true, keepSelection: true });
  }
  function syncEffectsStyle(doc) {
    const used = new Set();
    doc.body.querySelectorAll('*').forEach(el => el.classList.forEach(c => { if (ALL_FX[c]) used.add(c); }));
    let tag = doc.getElementById('mk-effects');
    if (!used.size) { if (tag) tag.remove(); return; }
    if (!tag) { tag = doc.createElement('style'); tag.id = 'mk-effects'; doc.head.appendChild(tag); }
    tag.textContent = '\n' + [...used].map(c => ALL_FX[c].css).join('\n') + '\n';
  }

  /* element actions */
  const needsRender = { render: true };
  $('actParent').onclick = () => {
    if (selId == null) return;
    const list = elementsOf(parse(source)), p = list[selId] && list[selId].parentElement;
    const idx = p ? list.indexOf(p) : -1;
    if (idx >= 0) post({ type: 'select', id: idx, reveal: true });
  };
  $('actClose').onclick = () => { post({ type: 'deselect' }); selId = null; hideInspector(); };
  $('actDel').onclick = () => {
    if (selId == null) return; const id = selId;
    if (id === 0) return;
    mutate((doc, list) => { list[id].remove(); return { select: null }; }, needsRender);
    selId = null; hideInspector();
  };
  $('actDup').onclick = () => {
    if (selId == null || selId === 0) return; const id = selId;
    mutate((doc, list) => { const el = list[id], c = el.cloneNode(true); el.after(c); return { select: c }; }, needsRender);
  };
  const move = dir => {
    if (selId == null || selId === 0) return; const id = selId;
    mutate((doc, list) => {
      const el = list[id];
      const sib = dir < 0 ? prevEl(el) : nextEl(el);
      if (!sib) return false;
      if (dir < 0) sib.before(el); else sib.after(el);
      return { select: el };
    }, needsRender);
  };
  const prevEl = el => { let n = el.previousElementSibling; while (n && SKIP.has(n.tagName)) n = n.previousElementSibling; return n; };
  const nextEl = el => { let n = el.nextElementSibling; while (n && SKIP.has(n.tagName)) n = n.nextElementSibling; return n; };
  $('actUp').onclick = () => move(-1);
  $('actDown').onclick = () => move(1);
  $('inspToggle').onclick = () => insp.classList.toggle('collapsed');

  /* add new elements */
  const PLACEHOLDER_IMG = "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180"><rect width="100%" height="100%" fill="#3b4670"/><circle cx="110" cy="75" r="22" fill="#8fa0d8"/><path d="M0 180 L120 100 L190 150 L250 110 L320 160 V180Z" fill="#8fa0d8"/></svg>');
  const TEMPLATES = {
    h2: () => { const e = document.createElement('h2'); e.textContent = 'عنوان جديد'; return e; },
    p: () => { const e = document.createElement('p'); e.textContent = 'نص جديد، اضغط عليه مرتين للتعديل'; return e; },
    button: () => { const e = document.createElement('button'); e.textContent = 'زر'; e.setAttribute('style', 'padding:12px 24px;border:0;border-radius:12px;background:#7566df;color:#fff;font-size:16px;font-weight:700'); return e; },
    img: () => { const e = document.createElement('img'); e.setAttribute('src', PLACEHOLDER_IMG); e.setAttribute('alt', ''); e.setAttribute('style', 'max-width:100%;border-radius:12px'); return e; },
    div: () => { const e = document.createElement('div'); e.textContent = 'صندوق'; e.setAttribute('style', 'padding:20px;border-radius:16px;background:rgba(255,255,255,.12);color:#fff'); return e; },
    a: () => { const e = document.createElement('a'); e.textContent = 'رابط'; e.setAttribute('href', '#'); e.setAttribute('style', 'color:#9ad8ff'); return e; }
  };
  const INLINE_PARENTS = /^(P|H[1-6]|BUTTON|A|SPAN|LABEL|LI|B|I|EM|STRONG|SMALL)$/;
  document.querySelectorAll('[data-add]').forEach(b => b.addEventListener('click', () => {
    const type = b.dataset.add, id = selId == null ? 0 : selId;
    mutate((doc, list) => {
      const target = list[id] || doc.body;
      const tpl = TEMPLATES[type]();
      const node = doc.importNode(tpl, true);
      if (target === doc.body) doc.body.appendChild(node);
      else {
        let anchor = target;
        while (anchor.parentElement && anchor.parentElement !== doc.body && INLINE_PARENTS.test(anchor.parentElement.tagName)) anchor = anchor.parentElement;
        anchor.after(node);
      }
      return { select: node };
    }, needsRender);
  }));

  /* ------------------------------------------------------------------ */
  /*  Keyframe animation editor — After-Effects style                     */
  /*                                                                      */
  /*  Every property (Position X/Y/Z, Rotation X/Y/Z, Scale, Opacity …)   */
  /*  has its OWN keyframes and its OWN easing curves (cubic-bezier, like */
  /*  AE's graph editor). The result is real CSS: one registered custom   */
  /*  property (@property --k-tx …) per track, each with its own          */
  /*  @keyframes, combined in a single `transform`. The editable model is */
  /*  kept in a small "mkk" JSON comment so the panel can reopen it.      */
  /* ------------------------------------------------------------------ */
  const kfPanel = $('kfPanel');
  const KF_CLASS = /^mkk-\d+$/;
  const KF_PROPS = [
    { k: 'tx',  g: 'Position',      label: 'Position X',        short: 'Pos X',   def: 0,   min: -500,  max: 500, step: 1,   unit: 'px' },
    { k: 'ty',  g: 'Position',      label: 'Position Y',        short: 'Pos Y',   def: 0,   min: -500,  max: 500, step: 1,   unit: 'px' },
    { k: 'tz',  g: 'Position',      label: 'Position Z (depth)', short: 'Pos Z',  def: 0,   min: -1000, max: 500, step: 1,   unit: 'px' },
    { k: 'rx',  g: '3D rotation',   label: 'Rotate X',          short: 'Rot X',   def: 0,   min: -720,  max: 720, step: 1,   unit: '°' },
    { k: 'ry',  g: '3D rotation',   label: 'Rotate Y',          short: 'Rot Y',   def: 0,   min: -720,  max: 720, step: 1,   unit: '°' },
    { k: 'rz',  g: '3D rotation',   label: 'Rotate Z',          short: 'Rot Z',   def: 0,   min: -720,  max: 720, step: 1,   unit: '°' },
    { k: 'sc',  g: 'Scale & skew',  label: 'Scale',             short: 'Scale',   def: 100, min: 0,     max: 400, step: 1,   unit: '%' },
    { k: 'sx',  g: 'Scale & skew',  label: 'Scale X',           short: 'Scale X', def: 100, min: 0,     max: 400, step: 1,   unit: '%' },
    { k: 'sy',  g: 'Scale & skew',  label: 'Scale Y',           short: 'Scale Y', def: 100, min: 0,     max: 400, step: 1,   unit: '%' },
    { k: 'skx', g: 'Scale & skew',  label: 'Skew',              short: 'Skew',    def: 0,   min: -60,   max: 60,  step: 1,   unit: '°' },
    { k: 'op',  g: 'Look',          label: 'Opacity',           short: 'Opacity', def: 100, min: 0,     max: 100, step: 1,   unit: '%' },
    { k: 'blur', g: 'Look',         label: 'Blur',              short: 'Blur',    def: 0,   min: 0,     max: 40,  step: 0.5, unit: 'px' },
    { k: 'bg',  g: 'Look',          label: 'Background color',  short: 'Color',   def: '',  color: true }
  ];
  const KF_BY = {};
  KF_PROPS.forEach(d => { KF_BY[d.k] = d; });

  /* ease curves = CSS cubic-bezier(x1,y1,x2,y2); null = linear; 'hold' = jump */
  const EZ = {
    linear: null,
    easy: [0.333, 0, 0.667, 1],
    slowStart: [0.42, 0, 1, 1],
    slowEnd: [0, 0, 0.58, 1],
    fastStart: [0.16, 1, 0.3, 1],
    fastEnd: [0.7, 0, 0.84, 0],
    overshoot: [0.34, 1.56, 0.64, 1],
    anticipate: [0.36, 0, 0.66, -0.56],
    hold: 'hold'
  };
  const EZ_LIST = [['Linear', 'linear'], ['Easy Ease', 'easy'], ['Slow start', 'slowStart'], ['Slow end', 'slowEnd'], ['Fast start', 'fastStart'],
    ['Fast end', 'fastEnd'], ['Overshoot', 'overshoot'], ['Anticipate', 'anticipate'], ['Hold', 'hold']];

  const r2 = n => Math.round(n * 100) / 100;
  const r3 = n => Math.round(n * 1000) / 1000;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const kfClone = o => JSON.parse(JSON.stringify(o));
  const sameEase = (a, b) => (!a && !b) || (a === b) || (Array.isArray(a) && Array.isArray(b) && a.every((x, i) => Math.abs(x - b[i]) < 0.002));
  const tfOf = e => !e ? 'linear' : e === 'hold' ? 'steps(1,end)' : 'cubic-bezier(' + e.map(r3).join(',') + ')';

  function bezY(e, x) {
    if (!e) return x;
    if (e === 'hold') return x >= 1 ? 1 : 0;
    const x1 = e[0], y1 = e[1], x2 = e[2], y2 = e[3];
    let lo = 0, hi = 1, t = x;
    for (let i = 0; i < 28; i++) {
      const u = 1 - t, cx = 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t;
      if (Math.abs(cx - x) < 1e-5) break;
      if (cx < x) lo = t; else hi = t;
      t = (lo + hi) / 2;
    }
    const u = 1 - t;
    return 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t;
  }
  const hex2rgb = h => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return [117, 102, 223]; const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const mixHex = (a, b, y) => {
    const A = hex2rgb(a), B = hex2rgb(b); y = clamp(y, 0, 1);
    return '#' + A.map((v, i) => ('0' + Math.round(v + (B[i] - v) * y).toString(16)).slice(-2)).join('');
  };

  /* segment lookup: key index i and eased progress y (0..1 …) inside segment i → i+1 */
  function segAt(ks, t) {
    const n = ks.length;
    if (t <= ks[0].t) return { i: 0, y: 0 };
    if (t >= ks[n - 1].t) return { i: n - 1, y: 0 };
    let i = 0;
    while (i < n - 2 && ks[i + 1].t <= t) i++;
    return { i, y: bezY(ks[i].e, (t - ks[i].t) / (ks[i + 1].t - ks[i].t)) };
  }
  function kfEval(a, k, t) {
    const d = KF_BY[k], pr = a.p[k];
    if (!pr) return d.def;
    const ks = pr.k;
    if (!ks.length) return pr.v;
    const s = segAt(ks, t), A = ks[s.i], B = ks[Math.min(s.i + 1, ks.length - 1)];
    return d.color ? mixHex(A.v, B.v, s.y) : A.v + (B.v - A.v) * s.y;
  }

  /* ---- model ---- */
  const OLD_EASE = { linear: null, ease: [0.25, 0.1, 0.25, 1], 'ease-in': [0.42, 0, 1, 1], 'ease-out': [0, 0, 0.58, 1], 'ease-in-out': [0.42, 0, 0.58, 1] };
  function kfMigrate(a) {          // Phase-3 animations (percent frames + one easing) → per-property tracks
    const dur = +a.dur || 2, map = { tx: 'tx', ty: 'ty', sc: 'sc', rot: 'rz', rx: 'rx', ry: 'ry', skx: 'skx', op: 'op' };
    let e = OLD_EASE[a.ease];
    if (e === undefined) { const m = /cubic-bezier\(([^)]+)\)/.exec(a.ease || ''); e = m ? m[1].split(',').map(Number) : EZ.easy; }
    const p = {};
    Object.keys(map).forEach(old => {
      const k = map[old], d = KF_BY[k], mul = k === 'sc' ? 100 : 1;
      const vals = a.frames.map(f => ({ t: (+f.p || 0) / 100 * dur, v: (f[old] === undefined ? d.def / mul : +f[old]) * mul, e }));
      if (vals.some(v => v.v !== d.def)) p[k] = { v: d.def, k: vals };
    });
    const bgs = a.frames.filter(f => f.bg).map(f => ({ t: (+f.p || 0) / 100 * dur, v: f.bg, e }));
    if (bgs.length) p.bg = { v: '', k: bgs };
    return p;
  }
  function kfNormalize(a) {
    const out = Object.assign({ name: 'mkk-1', dur: 2, delay: 0, iter: 'infinite', dir: 'normal', origin: 'center', persp: 800, hideBack: false, toggle: false }, a);
    out.trig = Object.assign({ mode: 'load', id: '' }, a.trig || {});
    const src = a.p || (Array.isArray(a.frames) ? kfMigrate(a) : {});
    out.iter = String(out.iter); out.dur = Math.max(0.2, +out.dur || 2); out.delay = Math.max(0, +out.delay || 0);
    out.persp = Math.max(50, +out.persp || 800);
    const p = {};
    let maxT = 0;
    KF_PROPS.forEach(d => {
      const s = src[d.k];
      if (!s) return;
      const ks = (Array.isArray(s.k) ? s.k : []).map(k => ({
        t: r2(Math.max(0, +k.t || 0)), v: d.color ? String(k.v || '#7566df') : (isFinite(+k.v) ? +k.v : d.def), e: k.e === undefined ? null : k.e
      })).sort((x, y) => x.t - y.t);
      ks.forEach(k => { maxT = Math.max(maxT, k.t); });
      p[d.k] = { v: d.color ? (s.v || '') : (s.v == null || !isFinite(+s.v) ? d.def : +s.v), k: ks };
    });
    out.p = p;
    out.dur = r2(Math.max(out.dur, maxT));
    delete out.frames; delete out.ease;
    return out;
  }
  const kfNew = name => kfNormalize({ name, dur: 2, iter: 'infinite', dir: 'alternate', p: {} });
  const kfProp = (a, k) => a.p[k] || (a.p[k] = { v: KF_BY[k].def, k: [] });
  const kfUsed = (a, k) => { const pr = a.p[k]; return !!pr && (pr.k.length > 0 || pr.v !== KF_BY[k].def); };
  const kfStartVal = (a, k) => { const pr = a.p[k]; return pr.k.length ? pr.k[0].v : pr.v; };

  /* ---- CSS ---- */
  const KF_AT_RULES = KF_PROPS.map(d => '@property --k-' + d.k + '{syntax:\'' + (d.color ? '<color>' : '<number>') + '\';inherits:false;initial-value:' + (d.color ? 'transparent' : d.def) + '}').join('\n');

  function kfKeyframes(a, d, nm) {
    const ks = a.p[d.k].k, pct = t => r3(t / a.dur * 100), fr = [];
    if (ks[0].t > 0) fr.push([0, ks[0].v, null]);
    ks.forEach(k => fr.push([k.t, k.v, k.e]));
    if (ks[ks.length - 1].t < a.dur) fr.push([a.dur, ks[ks.length - 1].v, null]);
    return '@keyframes ' + nm + '{' + fr.map((f, i) =>
      pct(f[0]) + '%{--k-' + d.k + ':' + (d.color ? f[1] : r3(f[1])) + (i < fr.length - 1 ? ';animation-timing-function:' + tfOf(f[2]) : '') + '}').join('') + '}';
  }
  function kfCss(a, inline) {
    const n = a.name, u = {};
    KF_PROPS.forEach(d => { u[d.k] = kfUsed(a, d.k); });
    const decl = [];
    KF_PROPS.forEach(d => { if (u[d.k]) decl.push('--k-' + d.k + ':' + (d.color ? kfStartVal(a, d.k) : r3(kfStartVal(a, d.k)))); });
    const T = [];
    if (u.rx || u.ry || u.tz) T.push('perspective(' + a.persp + 'px)');
    if (u.tx || u.ty || u.tz) T.push('translate3d(calc(var(--k-tx)*1px),calc(var(--k-ty)*1px),calc(var(--k-tz)*1px))');
    if (u.rx) T.push('rotateX(calc(var(--k-rx)*1deg))');
    if (u.ry) T.push('rotateY(calc(var(--k-ry)*1deg))');
    if (u.rz) T.push('rotate(calc(var(--k-rz)*1deg))');
    if (u.sc || u.sx || u.sy) T.push('scale(calc(var(--k-sc)*var(--k-sx)/10000),calc(var(--k-sc)*var(--k-sy)/10000))');
    if (u.skx) T.push('skewX(calc(var(--k-skx)*1deg))');
    if (T.length) decl.push('transform:' + T.join(' '));
    if (u.op) decl.push('opacity:calc(var(--k-op)/100)');
    if (u.blur) decl.push('filter:blur(calc(var(--k-blur)*1px))');
    if (u.bg) decl.push('background-color:var(--k-bg)');
    decl.push('transform-origin:' + a.origin);
    if (a.hideBack) decl.push('backface-visibility:hidden');
    if (inline) decl.push('display:inline-block');

    const anims = [], kfs = [];
    KF_PROPS.forEach(d => {
      const pr = a.p[d.k];
      if (!pr || !pr.k.length) return;
      const nm = n + '-' + d.k;
      anims.push(nm + ' ' + a.dur + 's linear ' + a.delay + 's ' + a.iter + ' ' + a.dir + ' both');
      kfs.push(kfKeyframes(a, d, nm));
    });
    const animDecl = anims.length ? 'animation:' + anims.join(',') : '';
    const mode = a.trig.mode;
    let css = kfs.join('\n') + (kfs.length ? '\n' : '');
    css += '.' + n + '{\n  ' + decl.concat(mode === 'load' && animDecl ? [animDecl] : []).join(';\n  ') + '\n}';
    if (animDecl && mode !== 'load') css += '\n' + (mode === 'hover' ? '.' + n + ':hover,' : '') + '.' + n + '.mkk-go{' + animDecl + '}';
    return css;
  }

  const RUNTIME = '\n(function(){var play=function(el){if(el.hasAttribute("data-mkk-toggle")&&el.classList.contains("mkk-go")){el.classList.remove("mkk-go");return}el.classList.remove("mkk-go");void el.offsetWidth;el.classList.add("mkk-go")};' +
    'document.querySelectorAll("[data-mkk-on]").forEach(function(el){var on=el.getAttribute("data-mkk-on");' +
    'if(on==="click"){el.addEventListener("click",function(){play(el)})}' +
    'else if(on.charAt(0)==="#"){var t=document.getElementById(on.slice(1));if(t)t.addEventListener("click",function(){play(el)})}})})();\n';
  function syncRuntime(doc) {
    const need = !!doc.querySelector('[data-mkk-on]');
    let s = doc.getElementById('mk-runtime');
    if (!need) { if (s) s.remove(); return; }
    if (!s) { s = doc.createElement('script'); s.id = 'mk-runtime'; doc.body.appendChild(s); }
    s.textContent = RUNTIME;
  }

  function readKf(doc) {
    const store = {}, tag = doc.getElementById('mk-keyframes');
    if (!tag) return store;
    const re = /\/\*mkk (\{[\s\S]*?\})\*\//g;
    let m;
    while ((m = re.exec(tag.textContent))) {
      try { const a = JSON.parse(m[1]); if (a && KF_CLASS.test(a.name || '')) store[a.name] = kfNormalize(a); } catch (_) {}
    }
    return store;
  }
  // Rebuilds the <style id="mk-keyframes"> block; animations no element uses any more are dropped.
  function writeKf(doc, store) {
    Object.keys(store).forEach(n => { if (!doc.body.querySelector('.' + n)) delete store[n]; });
    let tag = doc.getElementById('mk-keyframes');
    const names = Object.keys(store);
    if (!names.length) { if (tag) tag.remove(); return ''; }
    const text = '\n' + KF_AT_RULES + '\n' + names.map(n => {
      const el = doc.body.querySelector('.' + n);
      const inline = /^(A|SPAN|B|I|EM|STRONG|SMALL|LABEL|CODE)$/.test(el.tagName);
      return '/*mkk ' + JSON.stringify(store[n]) + '*/\n' + kfCss(store[n], inline);
    }).join('\n') + '\n';
    if (!tag) { tag = doc.createElement('style'); tag.id = 'mk-keyframes'; }
    doc.head.appendChild(tag);          // last in <head> so it wins over earlier rules
    tag.textContent = text;
    return text;
  }
  function kfNextName(doc, store) {
    let n = 0;
    Object.keys(store).forEach(k => { n = Math.max(n, +k.slice(4) || 0); });
    doc.body.querySelectorAll('*').forEach(el => el.classList.forEach(c => { if (KF_CLASS.test(c)) n = Math.max(n, +c.slice(4) || 0); }));
    return 'mkk-' + (n + 1);
  }
  function dropKfClass(doc, el) {
    const cls = [...el.classList].find(c => KF_CLASS.test(c));
    if (!cls) return;
    el.classList.remove(cls);
    el.removeAttribute('data-mkk-on'); el.removeAttribute('data-mkk-toggle');
    if (!el.getAttribute('class')) el.removeAttribute('class');
    writeKf(doc, readKf(doc));
    syncRuntime(doc);
  }

  /* ---- presets (times in seconds; key = [t, value, ease]) ---- */
  const K = (t, v, e) => ({ t, v, e: e === undefined ? null : e });
  const PR = (dur, iter, dir, tracks) => ({ dur, iter, dir, tracks });
  const KF_PRESETS = {
    'Pulse':      PR(1.2, 'infinite', 'normal', { sc: [K(0, 100, EZ.easy), K(0.6, 125, EZ.easy), K(1.2, 100)] }),
    'Spin':       PR(3, 'infinite', 'normal', { rz: [K(0, 0), K(3, 360)] }),
    'Slide':      PR(2, 'infinite', 'alternate', { tx: [K(0, -60, EZ.easy), K(2, 60)] }),
    'Bounce':     PR(1, 'infinite', 'normal', { ty: [K(0, 0, EZ.slowEnd), K(0.5, -36, EZ.slowStart), K(1, 0)] }),
    'Fade in':    PR(0.9, '1', 'normal', { op: [K(0, 0, EZ.slowEnd), K(0.9, 100)], ty: [K(0, 24, EZ.slowEnd), K(0.9, 0)] }),
    'Zoom in':    PR(0.8, '1', 'normal', { sc: [K(0, 40, EZ.overshoot), K(0.8, 100)], op: [K(0, 0), K(0.3, 100)] }),
    'Wobble':     PR(1.2, 'infinite', 'normal', { rz: [K(0, 0, EZ.easy), K(0.3, -8, EZ.easy), K(0.6, 8, EZ.easy), K(0.9, -5, EZ.easy), K(1.2, 0)] }),
    'Heartbeat':  PR(1.4, 'infinite', 'normal', { sc: [K(0, 100, EZ.easy), K(0.2, 125, EZ.easy), K(0.4, 100, EZ.easy), K(0.6, 125, EZ.easy), K(1, 100)] }),
    'Shake':      PR(0.8, 'infinite', 'normal', { tx: [K(0, 0), K(0.16, -9), K(0.32, 9), K(0.48, -9), K(0.64, 9), K(0.8, 0)] }),
    'Color':      PR(3, 'infinite', 'normal', { bg: [K(0, '#7566df', EZ.easy), K(1.5, '#35d0a0', EZ.easy), K(3, '#7566df')] }),
    '3D Flip Y':  PR(2, 'infinite', 'normal', { ry: [K(0, 0, EZ.easy), K(2, 360)] }),
    '3D Flip X':  PR(2, 'infinite', 'normal', { rx: [K(0, 0, EZ.easy), K(2, 360)] }),
    'Card flip':  PR(0.9, '1', 'normal', { ry: [K(0, 0, EZ.easy), K(0.9, 180)] }),
    'Tumble':     PR(4, 'infinite', 'normal', { rx: [K(0, 0), K(4, 360)], ry: [K(0, 0), K(4, 360)] }),
    'Fly in 3D':  PR(1.1, '1', 'normal', { tz: [K(0, -700, EZ.slowEnd), K(1.1, 0)], ry: [K(0, 70, EZ.slowEnd), K(1.1, 0)], op: [K(0, 0), K(0.5, 100)] }),
    'Pop up 3D':  PR(0.7, '1', 'normal', { sc: [K(0, 0, EZ.overshoot), K(0.7, 100)], rx: [K(0, -90, EZ.slowEnd), K(0.7, 0)] }),
    'Swing 3D':   PR(3, 'infinite', 'normal', { ry: [K(0, -35, EZ.easy), K(1.5, 35, EZ.easy), K(3, -35)] }),
    'Orbit':      PR(4, 'infinite', 'normal', {
      tx: [K(0, 0, EZ.easy), K(1, 120, EZ.easy), K(2, 0, EZ.easy), K(3, -120, EZ.easy), K(4, 0)],
      tz: [K(0, 0, EZ.easy), K(1, -120, EZ.easy), K(2, -240, EZ.easy), K(3, -120, EZ.easy), K(4, 0)]
    })
  };

  /* ================== panel UI ================== */
  const tlRows = $('tlRows'), tlRuler = $('tlRuler');
  const rowEls = {};
  const kfDec = d => (d.step && d.step < 1 ? 1 : 0);
  const fmtV = (d, v) => d.color ? v : String(r2(v));
  const SW_SVG = '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="8" cy="9.2" r="5"/><path d="M8 9.2V6.6M6.4 2.2h3.2"/></svg>';

  function kfBuildRows() {
    tlRows.textContent = '';
    let lastG = null;
    KF_PROPS.forEach(d => {
      if (d.g !== lastG) {
        lastG = d.g;
        const h = document.createElement('div');
        h.className = 'tl-group'; h.textContent = d.g;
        tlRows.appendChild(h);
      }
      const row = document.createElement('div');
      row.className = 'tl-row'; row.dataset.k = d.k;
      row.innerHTML = '<div class="tl-label"><button type="button" class="sw" title="Stopwatch: start / stop animating ' + d.label + '">' + SW_SVG + '</button>' +
        '<span class="nm" title="Tap to select · drag sideways to change the value">' + d.short + '</span>' +
        (d.color ? '<input class="val" type="color" value="#7566df">' : '<input class="val" type="number" inputmode="decimal" step="' + d.step + '">') +
        '</div><div class="tl-lane"></div>';
      tlRows.appendChild(row);
      const o = { row, sw: row.querySelector('.sw'), nm: row.querySelector('.nm'), val: row.querySelector('.val'), lane: row.querySelector('.tl-lane') };
      rowEls[d.k] = o;

      o.sw.onclick = () => kfStopwatch(d.k);
      o.val.addEventListener('input', () => { if (o.val.value === '' ) return; kfSetVal(d.k, d.color ? o.val.value : +o.val.value); });
      o.val.addEventListener('focus', () => { kf && (kf.gp = d.k); });

      // drag on the name = scrub the value (like AE)
      let sd = null;
      o.nm.addEventListener('pointerdown', e => {
        if (!kf) return;
        o.nm.setPointerCapture(e.pointerId);
        kf.gp = d.k; kfRefreshSel();
        sd = { x: e.clientX, v: kfEval(kf.anim, d.k, kf.head), moved: false };
      });
      o.nm.addEventListener('pointermove', e => {
        if (!sd || d.color) return;
        const dx = e.clientX - sd.x;
        if (Math.abs(dx) < 4 && !sd.moved) return;
        sd.moved = true;
        const stepV = d.step || 1;
        kfSetVal(d.k, Math.round((sd.v + dx * (d.max - d.min) / 280) / stepV) * stepV);
      });
      const end = () => { sd = null; };
      o.nm.addEventListener('pointerup', end); o.nm.addEventListener('pointercancel', end);

      // lane: tap/drag = move playhead; drag a diamond = move that keyframe in time
      let ld = null;
      o.lane.addEventListener('pointerdown', e => {
        if (!kf) return;
        const kb = e.target.closest('.kf-key');
        o.lane.setPointerCapture(e.pointerId);
        kf.gp = d.k;
        if (kb && kb._key) {
          kf.sel = { k: d.k, key: kb._key };
          ld = { key: kb._key, x: e.clientX, moved: false };
          kfSeek(kb._key.t);
        } else {
          ld = { seek: true };
          kfSeek(kfLaneT(o.lane, e.clientX));
        }
      });
      o.lane.addEventListener('pointermove', e => {
        if (!ld || !kf) return;
        if (ld.seek) { kfSeek(kfLaneT(o.lane, e.clientX)); return; }
        if (!ld.moved && Math.abs(e.clientX - ld.x) < 4) return;
        ld.moved = true;
        const ks = kf.anim.p[d.k].k, i = ks.indexOf(ld.key);
        const lo = i > 0 ? ks[i - 1].t + 0.01 : 0, hi = i < ks.length - 1 ? ks[i + 1].t - 0.01 : kf.anim.dur;
        ld.key.t = r2(clamp(kfLaneT(o.lane, e.clientX), lo, hi));
        kfSeek(ld.key.t);
        kfEdited('keytime');
      });
      const lend = () => { ld = null; };
      o.lane.addEventListener('pointerup', lend); o.lane.addEventListener('pointercancel', lend);
    });

    // ruler scrub
    let rd = false;
    tlRuler.addEventListener('pointerdown', e => { if (!kf) return; rd = true; tlRuler.setPointerCapture(e.pointerId); kfSeek(kfLaneT(tlRuler, e.clientX)); });
    tlRuler.addEventListener('pointermove', e => { if (rd && kf) kfSeek(kfLaneT(tlRuler, e.clientX)); });
    tlRuler.addEventListener('pointerup', () => { rd = false; });
    tlRuler.addEventListener('pointercancel', () => { rd = false; });

    // presets, ease chips, graph property list
    KF_PROPS.forEach(d => { const o = document.createElement('option'); o.value = d.k; o.textContent = d.label; $('kfGProp').appendChild(o); });
  }
  function kfLaneT(lane, clientX) {
    const r = lane.getBoundingClientRect();
    return r2(clamp((clientX - r.left) / r.width, 0, 1) * kf.anim.dur);
  }

  Object.keys(KF_PRESETS).forEach(name => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = name; b.onclick = () => kfPreset(name);
    $('kfPresets').appendChild(b);
  });
  EZ_LIST.forEach(([label, id]) => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = label; b.dataset.ez = id;
    b.onclick = () => kfApplyEase(EZ[id]);
    $('kfEaseChips').appendChild(b);
  });

  /* ---- drawing the timeline ---- */
  const keyAt = (pr, t) => pr.k.find(k => Math.abs(k.t - t) < 0.005);
  function kfRefreshRows(light) {
    const a = kf.anim, dur = a.dur;
    if (!light) {
      // ruler ticks
      const w = tlRuler.clientWidth || 200, want = Math.max(2, Math.floor(w / 42));
      const steps = [0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 60];
      const step = steps.find(s => dur / s <= want) || 60;
      let html = '';
      for (let t = 0; t <= dur + 1e-6; t += step) html += '<i style="left:' + (t / dur * 100) + '%"><b>' + r2(t) + '</b></i>';
      tlRuler.innerHTML = html;
    }
    KF_PROPS.forEach(d => {
      const o = rowEls[d.k], pr = a.p[d.k], animated = !!pr && pr.k.length > 0;
      if (!light) {
      o.sw.classList.toggle('on', animated);
      o.row.classList.toggle('sel', kf.gp === d.k);
      o.lane.textContent = '';
      if (animated) {
        const first = pr.k[0], last = pr.k[pr.k.length - 1];
        if (last.t > first.t) {
          const bar = document.createElement('u');
          bar.style.left = (first.t / dur * 100) + '%'; bar.style.width = ((last.t - first.t) / dur * 100) + '%';
          o.lane.appendChild(bar);
        }
        pr.k.forEach(key => {
          const b = document.createElement('i');
          b.className = 'kf-key' + (key.e === 'hold' ? ' hold' : key.e ? ' eased' : '') + (kf.sel && kf.sel.key === key ? ' sel' : '');
          b.style.left = (key.t / dur * 100) + '%';
          b._key = key;
          o.lane.appendChild(b);
        });
      }
      }
      const v = kfEval(a, d.k, kf.head);
      if (document.activeElement !== o.val) o.val.value = d.color ? (v || '#7566df') : fmtV(d, v);
      o.val.classList.toggle('lit', animated && !!keyAt(pr, kf.head));
    });
    kfRefreshHead();
  }
  function kfRefreshHead() {
    const a = kf.anim;
    $('tlPh').style.setProperty('--p', a.dur ? kf.head / a.dur : 0);
    $('kfTime').textContent = r2(kf.head).toFixed(2) + 's';
    $('kfPlay').textContent = kf.playing ? '⏸' : '▶';
    $('kfPlay').classList.toggle('on', kf.playing);
    $('kfLoop').classList.toggle('on', a.iter === 'infinite');
  }
  function kfRefreshSel() {
    if (!kf) return;
    const a = kf.anim, k = kf.gp, d = KF_BY[k], pr = a.p[k], v = kfEval(a, k, kf.head);
    $('kfSelName').textContent = d.label;
    $('kfSelVal').textContent = d.color ? (v || '') : r2(v) + d.unit;
    const sl = $('kfSelSlider'), col = $('kfSelColor');
    sl.classList.toggle('hidden', !!d.color); col.classList.toggle('hidden', !d.color);
    if (d.color) col.value = v || '#7566df';
    else { sl.min = d.min; sl.max = d.max; sl.step = d.step; sl.value = v; }
    const here = pr && keyAt(pr, kf.head);
    $('kfAddKey').classList.toggle('on', !!here);
    $('kfDelKey').disabled = !(kf.sel && kf.sel.k === k && pr && pr.k.includes(kf.sel.key));
    Object.keys(rowEls).forEach(x => rowEls[x].row.classList.toggle('sel', x === k));
    $('kfGProp').value = k;
    // ease chips reflect the selected key's outgoing curve
    const seg = kfActiveSeg();
    document.querySelectorAll('#kfEaseChips button').forEach(b => b.classList.toggle('on', !!seg && sameEase(seg.a.e, EZ[b.dataset.ez])));
    document.querySelectorAll('#kfEaseChips button').forEach(b => { b.disabled = !seg; });
  }
  function kfRefresh() {
    if (!kf) return;
    const a = kf.anim;
    kfRefreshRows();
    kfRefreshSel();
    if (kf.tab === 'graph') kfDrawGraph();
    if (kf.tab === 'setup') kfRefreshSetup();
  }
  function kfRefreshSetup() {
    const a = kf.anim;
    $('kfDelay').value = a.delay; $('kfDur').value = a.dur; $('kfPersp').value = a.persp;
    $('kfOrigin').value = a.origin; $('kfBack').checked = !!a.hideBack;
    $('kfToggleStop').checked = !!a.toggle;
    $('kfToggleRow').classList.toggle('hidden', a.trig.mode !== 'click' && a.trig.mode !== 'other');
    document.querySelectorAll('#kfIter button').forEach(b => b.classList.toggle('on', b.dataset.v === String(a.iter)));
    document.querySelectorAll('#kfDir button').forEach(b => b.classList.toggle('on', b.dataset.v === a.dir));
    document.querySelectorAll('#kfTrig button').forEach(b => b.classList.toggle('on', b.dataset.v === a.trig.mode));
    const other = a.trig.mode === 'other';
    $('kfPickRow').classList.toggle('hidden', !other);
    let label = 'Not chosen yet';
    if (other && a.trig.id) {
      const t = parse(source).getElementById(a.trig.id);
      label = t ? '<' + t.tagName.toLowerCase() + '> ' + (t.textContent.trim().slice(0, 22) || '#' + a.trig.id) : 'Element missing — pick again';
    }
    $('kfPickBtn').textContent = kf.pick ? 'Tap the button in the preview…' : (a.trig.id ? 'Change button' : 'Pick button in preview');
    $('kfPickBtn').classList.toggle('on', !!kf.pick);
    $('kfPickLabel').textContent = other ? label : '';
    const hints = {
      load: 'Plays by itself when the page opens.',
      click: 'Starts when this element is tapped (after the wait below).',
      hover: 'Plays while the pointer is over this element.',
      other: 'Starts when the chosen button is tapped (after the wait below).'
    };
    $('kfTrigHint').textContent = hints[a.trig.mode] + ' Preview here with ▶ — or press Run above the preview to test the real taps.';
  }

  /* ---- sending state to the preview ---- */
  function kfScrubPost() {
    if (!kf) return;
    post({ type: 'kfscrub', id: kf.elId, t: Math.round(kf.head * 1000) / 1000 });
  }
  function kfStopClock() {
    if (!kf) return;
    kf.playing = false;
    if (kf.raf) { cancelAnimationFrame(kf.raf); kf.raf = 0; }
  }
  function kfSeek(t) {
    if (!kf) return;
    kfStopClock();
    kf.head = clamp(r2(t), 0, kf.anim.dur);
    kf.scrubbed = true;
    kfRefreshRows(); kfRefreshSel();
    if (kf.tab === 'graph') kfDrawGraph();
    kfScrubPost();
  }
  function kfPause() {
    if (!kf || !kf.playing) return;
    kfStopClock();
    kf.scrubbed = true;
    kfScrubPost();
    kfRefreshHead();
  }
  function kfPlay() {
    if (!kf) return;
    const a = kf.anim;
    kfStopClock();
    if (kf.head >= a.dur - 0.01) kf.head = 0;
    kf.playing = true; kf.scrubbed = false;
    kf.from = kf.head;
    kf.t0 = performance.now() - (kf.from > 0 ? kf.from + a.delay : 0) * 1000;
    post({ type: 'kfplay', id: kf.elId, from: kf.from });
    const tick = () => {
      if (!kf || !kf.playing) return;
      const A = kf.anim, x = Math.max(0, (performance.now() - kf.t0) / 1000 - A.delay);
      const iters = A.iter === 'infinite' ? Infinity : +A.iter, cyc = x / A.dur;
      let n = Math.floor(cyc), f = cyc - n, done = false;
      if (n >= iters) { done = true; n = iters - 1; f = 1; }
      const dir = kf.from > 0 ? 'normal' : A.dir;
      const pos = dir === 'normal' ? f : dir === 'reverse' ? 1 - f : (n % 2 === 0 ? f : 1 - f);
      kf.head = pos * A.dur;
      if (done) { kfStopClock(); kf.scrubbed = true; kfScrubPost(); kfRefreshRows(); kfRefreshSel(); if (kf.tab === 'graph') kfDrawGraph(); return; }
      kfRefreshRows(true);
      kfRefreshSel();
      if (kf.tab === 'graph') kfDrawGraph();
      kf.raf = requestAnimationFrame(tick);
    };
    kf.raf = requestAnimationFrame(tick);
    kfRefreshHead();
  }

  /* ---- editing ---- */
  let commitRaf = 0, commitKey = '';
  function kfCommitSoon(key) {
    commitKey = key;
    if (commitRaf) return;
    commitRaf = requestAnimationFrame(() => { commitRaf = 0; kfCommit(commitKey); });
  }
  function kfEdited(key) {
    if (!kf) return;
    kfPause();
    kfRefresh();
    kfCommitSoon(key);
  }
  function kfCommit(key) {
    if (!kf) return;
    const id = kf.elId, anim = kf.anim, first = !kf.applied;
    let cssText = '';
    mutate((doc, list) => {
      const el = list[id]; if (!el) return false;
      const store = readKf(doc);
      const cur = [...el.classList].find(c => KF_CLASS.test(c));
      if (cur && cur !== anim.name) el.classList.remove(cur);
      el.classList.add(anim.name);
      Object.keys(FX.anim).forEach(c => el.classList.remove(c));   // keyframes replace preset animations
      const tg = anim.trig;
      if (tg.mode === 'click') el.setAttribute('data-mkk-on', 'click');
      else if (tg.mode === 'other' && tg.id && doc.getElementById(tg.id)) el.setAttribute('data-mkk-on', '#' + tg.id);
      else el.removeAttribute('data-mkk-on');
      if (anim.toggle && el.hasAttribute('data-mkk-on')) el.setAttribute('data-mkk-toggle', ''); else el.removeAttribute('data-mkk-toggle');
      store[anim.name] = kfClone(anim);
      cssText = writeKf(doc, store);
      syncRuntime(doc);
      syncEffectsStyle(doc);
    }, { key: 'kf:' + key, render: first, keepSelection: true });
    kf.applied = true;
    if (!first) {
      post({ type: 'kfcss', css: cssText });   // live update without reloading the preview
      if (kf.scrubbed) kfScrubPost();
    }
  }

  function kfAddKeyAt(k, t, v) {
    const pr = kfProp(kf.anim, k);
    const key = { t: r2(t), v, e: null };
    pr.k.push(key);
    pr.k.sort((x, y) => x.t - y.t);
    kf.sel = { k, key };
    return key;
  }
  function kfSetVal(k, v) {
    if (!kf) return;
    const d = KF_BY[k], pr = kfProp(kf.anim, k);
    if (!d.color) { v = +v; if (!isFinite(v)) return; v = r3(v); }
    kf.gp = k;
    if (pr.k.length) {
      let key = keyAt(pr, kf.head);
      if (!key) key = kfAddKeyAt(k, kf.head, v);
      key.v = v; kf.sel = { k, key };
    } else pr.v = v;
    kfEdited('p:' + k);
  }
  function kfStopwatch(k) {
    if (!kf) return;
    const a = kf.anim, pr = kfProp(a, k), d = KF_BY[k];
    kf.gp = k;
    if (pr.k.length) { pr.v = kfEval(a, k, kf.head); pr.k = []; kf.sel = null; }
    else { kfAddKeyAt(k, kf.head, pr.v === '' && d.color ? '#7566df' : pr.v); }
    kfEdited('sw:' + k);
  }
  function kfToggleKey() {
    if (!kf) return;
    const a = kf.anim, k = kf.gp, pr = kfProp(a, k), cur = keyAt(pr, kf.head);
    if (cur) {
      const v = cur.v;
      pr.k = pr.k.filter(x => x !== cur);
      if (!pr.k.length) pr.v = v;
      kf.sel = null;
    } else {
      kfAddKeyAt(k, kf.head, kfEval(a, k, kf.head) || (KF_BY[k].color ? '#7566df' : 0));
    }
    kfEdited('keytoggle');
  }
  function kfDelSelKey() {
    if (!kf || !kf.sel) return;
    const pr = kfProp(kf.anim, kf.sel.k), v = kf.sel.key.v;
    pr.k = pr.k.filter(x => x !== kf.sel.key);
    if (!pr.k.length) pr.v = v;
    kf.sel = null;
    kfEdited('keydel');
  }
  function kfJump(dir) {
    if (!kf) return;
    const ks = kfProp(kf.anim, kf.gp).k;
    const t = dir < 0 ? [...ks].reverse().find(k => k.t < kf.head - 0.004) : ks.find(k => k.t > kf.head + 0.004);
    if (!t) return;
    kf.sel = { k: kf.gp, key: t };
    kfSeek(t.t);
  }

  /* the segment the ease tools work on: the one leaving the selected key (or arriving, for the last key) */
  function kfActiveSeg() {
    if (!kf || !kf.sel) return null;
    const ks = kf.anim.p[kf.sel.k] && kf.anim.p[kf.sel.k].k;
    if (!ks) return null;
    const i = ks.indexOf(kf.sel.key);
    if (i < 0 || ks.length < 2) return null;
    const s = i < ks.length - 1 ? i : i - 1;
    return { k: kf.sel.k, ks, i: s, a: ks[s], b: ks[s + 1] };
  }
  function kfApplyEase(e) {
    const seg = kfActiveSeg();
    if (!seg) { flash('Select a keyframe first'); return; }
    const all = $('kfEaseAll').checked;
    (all ? seg.ks.slice(0, -1) : [seg.a]).forEach(k => { k.e = e && e !== 'hold' ? e.slice() : e; });
    kfEdited('ease');
  }

  function kfPreset(name) {
    if (!kf) return;
    const p = KF_PRESETS[name], a = kf.anim;
    a.p = {};
    Object.keys(p.tracks).forEach(k => {
      a.p[k] = { v: KF_BY[k].def, k: kfClone(p.tracks[k]) };
    });
    Object.assign(a, { dur: p.dur, iter: p.iter, dir: p.dir, delay: 0 });
    kf.sel = null; kf.head = 0;
    const first = Object.keys(p.tracks)[0]; if (first) kf.gp = first;
    kfRefresh();
    kfCommit('preset');
    kfPlay();
  }

  /* ================== graph editor (value graph with bezier handles) ================== */
  const svgGraph = $('kfGraph');
  const SVGNS = 'http://www.w3.org/2000/svg';
  let gLock = null;
  function gLayout() {
    const W = svgGraph.clientWidth || 320, H = svgGraph.clientHeight || 230;
    return { W, H, pl: 38, pr: 14, pt: 14, pb: 22 };
  }
  // numeric stand-in for a key (colors use their index so the curve can still be shaped)
  const gVal = (k, ks, i) => KF_BY[k].color ? i : ks[i].v;
  function gNumAt(k, ks, t) {
    const s = segAt(ks, t), j = Math.min(s.i + 1, ks.length - 1);
    return gVal(k, ks, s.i) + (gVal(k, ks, j) - gVal(k, ks, s.i)) * s.y;
  }
  function gRange(k, ks) {
    let lo = Infinity, hi = -Infinity;
    for (let i = 0; i <= 80; i++) { const v = gNumAt(k, ks, i / 80 * kf.anim.dur); lo = Math.min(lo, v); hi = Math.max(hi, v); }
    ks.forEach((_, i) => { lo = Math.min(lo, gVal(k, ks, i)); hi = Math.max(hi, gVal(k, ks, i)); });
    const seg = kfActiveSeg();
    if (seg && seg.k === k && Array.isArray(seg.a.e)) {
      const v0 = gVal(k, ks, seg.i), v1 = gVal(k, ks, seg.i + 1);
      [seg.a.e[1], seg.a.e[3]].forEach(y => { const v = v0 + (v1 - v0) * y; lo = Math.min(lo, v); hi = Math.max(hi, v); });
    }
    if (hi - lo < 1e-6) { const m = Math.abs(hi) > 1 ? Math.abs(hi) * 0.25 : 1; lo -= m; hi += m; }
    const pad = (hi - lo) * 0.14;
    return { lo: lo - pad, hi: hi + pad };
  }
  function kfDrawGraph() {
    if (!kf) return;
    const a = kf.anim, k = kf.gp, d = KF_BY[k], pr = a.p[k], ks = pr ? pr.k : [];
    const g = gLayout(), info = $('kfGInfo'), cub = $('kfCubic');
    svgGraph.setAttribute('viewBox', '0 0 ' + g.W + ' ' + g.H);
    if (ks.length < 1) {
      svgGraph.innerHTML = '<text x="' + g.W / 2 + '" y="' + g.H / 2 + '" text-anchor="middle" class="g-empty">Tap ⏱ on this property in the Timeline to animate it</text>';
      info.textContent = ''; cub.textContent = ''; svgGraph._geom = null;
      return;
    }
    const rg = (gLock && gLock.k === k) ? gLock.rg : gRange(k, ks);
    const X = t => g.pl + t / a.dur * (g.W - g.pl - g.pr);
    const Y = v => g.H - g.pb - (v - rg.lo) / (rg.hi - rg.lo) * (g.H - g.pt - g.pb);
    let s = '';
    // grid
    for (let i = 0; i <= 4; i++) {
      const v = rg.lo + (rg.hi - rg.lo) * i / 4, y = Y(v);
      s += '<line class="g-grid" x1="' + g.pl + '" x2="' + (g.W - g.pr) + '" y1="' + y + '" y2="' + y + '"/>';
      if (!d.color) s += '<text class="g-lbl" x="' + (g.pl - 5) + '" y="' + (y + 3) + '" text-anchor="end">' + ((rg.hi - rg.lo) > 12 ? Math.round(v) : r2(v)) + '</text>';
    }
    const steps = [0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 60], want = Math.max(2, Math.floor((g.W - g.pl) / 50));
    const step = steps.find(x => a.dur / x <= want) || 60;
    for (let t = 0; t <= a.dur + 1e-6; t += step) {
      s += '<line class="g-grid v" x1="' + X(t) + '" x2="' + X(t) + '" y1="' + g.pt + '" y2="' + (g.H - g.pb) + '"/>' +
        '<text class="g-lbl" x="' + X(t) + '" y="' + (g.H - 6) + '" text-anchor="middle">' + r2(t) + '</text>';
    }
    // curve
    let path = '';
    const N = 220;
    for (let i = 0; i <= N; i++) { const t = i / N * a.dur; path += (i ? 'L' : 'M') + X(t).toFixed(1) + ' ' + Y(gNumAt(k, ks, t)).toFixed(1); }
    s += '<path class="g-curve" d="' + path + '"/>';
    // active segment highlighted
    const seg = kfActiveSeg();
    if (seg && seg.k === k) {
      let sp = '';
      for (let i = 0; i <= 60; i++) { const t = seg.a.t + (seg.b.t - seg.a.t) * i / 60; sp += (i ? 'L' : 'M') + X(t).toFixed(1) + ' ' + Y(gNumAt(k, ks, t)).toFixed(1); }
      s += '<path class="g-seg" d="' + sp + '"/>';
    }
    // playhead
    s += '<line class="g-ph" x1="' + X(kf.head) + '" x2="' + X(kf.head) + '" y1="' + g.pt + '" y2="' + (g.H - g.pb) + '"/>';
    // handles of the active segment
    if (seg && seg.k === k && seg.a.e !== 'hold') {
      const h = gHandles(seg, k, X, Y);
      s += '<line class="g-hl" x1="' + h.n0.x + '" y1="' + h.n0.y + '" x2="' + h.h1.x + '" y2="' + h.h1.y + '"/>' +
           '<line class="g-hl" x1="' + h.n1.x + '" y1="' + h.n1.y + '" x2="' + h.h2.x + '" y2="' + h.h2.y + '"/>' +
           '<circle class="g-h" cx="' + h.h1.x + '" cy="' + h.h1.y + '" r="7"/><circle class="g-h" cx="' + h.h2.x + '" cy="' + h.h2.y + '" r="7"/>';
    }
    // keyframe nodes
    ks.forEach((key, i) => {
      s += '<circle class="g-n' + (kf.sel && kf.sel.key === key ? ' sel' : '') + '" cx="' + X(key.t) + '" cy="' + Y(gVal(k, ks, i)) + '" r="6.5"/>';
    });
    svgGraph.innerHTML = s;
    info.textContent = d.color ? 'color — curve shows progress between keys' : ks.length + (ks.length === 1 ? ' keyframe' : ' keyframes');
    if (seg && seg.k === k) {
      const e = seg.a.e;
      cub.textContent = e === 'hold' ? 'Hold — jumps to the next value' : 'cubic-bezier(' + (e ? e.map(r3).join(', ') : '0.333, 0.333, 0.667, 0.667 · linear') + ')';
    } else cub.textContent = ks.length > 1 ? 'Tap a keyframe dot, then drag the round handles to shape the speed.' : 'Add a second keyframe to shape the motion between them.';
    svgGraph._geom = { g, X, Y, rg };
  }
  function gHandles(seg, k, X, Y) {
    const ks = seg.ks, t0 = seg.a.t, t1 = seg.b.t, v0 = gVal(k, ks, seg.i), v1 = gVal(k, ks, seg.i + 1);
    const e = Array.isArray(seg.a.e) ? seg.a.e : [1 / 3, 1 / 3, 2 / 3, 2 / 3];
    return {
      n0: { x: X(t0), y: Y(v0) }, n1: { x: X(t1), y: Y(v1) },
      h1: { x: X(t0 + e[0] * (t1 - t0)), y: Y(v0 + e[1] * (v1 - v0)) },
      h2: { x: X(t0 + e[2] * (t1 - t0)), y: Y(v0 + e[3] * (v1 - v0)) }
    };
  }
  svgGraph.addEventListener('pointerdown', e => {
    if (!kf || !svgGraph._geom) return;
    const { g, X, Y, rg } = svgGraph._geom, r = svgGraph.getBoundingClientRect();
    const px = e.clientX - r.left, py = e.clientY - r.top, k = kf.gp, ks = (kf.anim.p[k] || {}).k || [];
    svgGraph.setPointerCapture(e.pointerId);
    const near = (p, rad) => Math.hypot(p.x - px, p.y - py) <= (rad || 16);
    const seg = kfActiveSeg();
    // 1. handles
    if (seg && seg.k === k && seg.a.e !== 'hold') {
      const h = gHandles(seg, k, X, Y);
      const c1 = Math.hypot(h.h1.x - px, h.h1.y - py), c2 = Math.hypot(h.h2.x - px, h.h2.y - py);
      if (Math.min(c1, c2) <= 20) {
        kfPause();
        gLock = { k, rg };
        kf.gd = { type: c1 <= c2 ? 'h1' : 'h2', seg };
        if (!Array.isArray(seg.a.e)) seg.a.e = [1 / 3, 1 / 3, 2 / 3, 2 / 3];
        return;
      }
    }
    // 2. keyframe nodes
    for (let i = 0; i < ks.length; i++) {
      if (near({ x: X(ks[i].t), y: Y(gVal(k, ks, i)) }, 16)) {
        kf.sel = { k, key: ks[i] };
        kf.gd = { type: 'node', key: ks[i], moved: false, x: px, y: py };
        gLock = { k, rg };
        kfSeek(ks[i].t);
        return;
      }
    }
    // 3. empty space → move the playhead
    kf.gd = { type: 'seek' };
    kfSeek(clamp((px - g.pl) / (g.W - g.pl - g.pr), 0, 1) * kf.anim.dur);
  });
  svgGraph.addEventListener('pointermove', e => {
    if (!kf || !kf.gd || !svgGraph._geom) return;
    const { g, rg } = svgGraph._geom, r = svgGraph.getBoundingClientRect();
    const px = e.clientX - r.left, py = e.clientY - r.top, a = kf.anim, k = kf.gp, d = KF_BY[k];
    const tOf = x => clamp((x - g.pl) / (g.W - g.pl - g.pr), 0, 1) * a.dur;
    const vOf = y => rg.lo + (g.H - g.pb - y) / (g.H - g.pt - g.pb) * (rg.hi - rg.lo);
    const gd = kf.gd;
    if (gd.type === 'seek') { kfSeek(tOf(px)); return; }
    if (gd.type === 'node') {
      if (!gd.moved && Math.hypot(px - gd.x, py - gd.y) < 4) return;
      gd.moved = true;
      const ks = a.p[k].k, i = ks.indexOf(gd.key);
      const lo = i > 0 ? ks[i - 1].t + 0.01 : 0, hi = i < ks.length - 1 ? ks[i + 1].t - 0.01 : a.dur;
      gd.key.t = r2(clamp(tOf(px), lo, hi));
      if (!d.color) gd.key.v = r2(clamp(vOf(py), -1e5, 1e5));
      kf.head = gd.key.t;
      kfEdited('node');
      return;
    }
    // handle drag
    const seg = gd.seg, ks = seg.ks, t0 = seg.a.t, t1 = seg.b.t, v0 = gVal(k, ks, seg.i), v1 = gVal(k, ks, seg.i + 1);
    const nx = clamp((tOf(px) - t0) / (t1 - t0), 0, 1);
    const dv = v1 - v0, ny = Math.abs(dv) < 1e-9 ? null : clamp((vOf(py) - v0) / dv, -3, 4);
    const ee = seg.a.e;
    if (gd.type === 'h1') { ee[0] = r3(nx); if (ny !== null) ee[1] = r3(ny); }
    else { ee[2] = r3(nx); if (ny !== null) ee[3] = r3(ny); }
    kfEdited('bezier');
  });
  const gEnd = () => { if (kf) kf.gd = null; gLock = null; if (kf && kf.tab === 'graph') kfDrawGraph(); };
  svgGraph.addEventListener('pointerup', gEnd);
  svgGraph.addEventListener('pointercancel', gEnd);

  /* ================== wiring ================== */
  $('kfToStart').onclick = () => kfSeek(0);
  $('kfPlay').onclick = () => { if (!kf) return; if (kf.playing) kfPause(); else kfPlay(); };
  $('kfAddKey').onclick = kfToggleKey;
  $('kfDelKey').onclick = kfDelSelKey;
  $('kfPrevKey').onclick = () => kfJump(-1);
  $('kfNextKey').onclick = () => kfJump(1);
  $('kfSelSlider').addEventListener('input', e => kf && kfSetVal(kf.gp, +e.target.value));
  $('kfSelColor').addEventListener('input', e => kf && kfSetVal(kf.gp, e.target.value));
  $('kfGProp').addEventListener('change', e => { if (!kf) return; kf.gp = e.target.value; kf.sel = null; kfRefresh(); });
  $('kfToggle').onclick = () => kfPanel.classList.toggle('collapsed');
  document.querySelectorAll('#kfTabs button').forEach(b => b.addEventListener('click', () => {
    if (!kf) return;
    kf.tab = b.dataset.tab;
    document.querySelectorAll('#kfTabs button').forEach(x => x.classList.toggle('on', x === b));
    $('kfVTime').classList.toggle('hidden', kf.tab !== 'time');
    $('kfVGraph').classList.toggle('hidden', kf.tab !== 'graph');
    $('kfVSetup').classList.toggle('hidden', kf.tab !== 'setup');
    $('kfEase').classList.toggle('hidden', kf.tab === 'setup');
    if (kf.pick && kf.tab !== 'setup') { kf.pick = false; }
    requestAnimationFrame(kfRefresh);
  }));

  const numField = (id, field, min, max, after) => $(id).addEventListener('input', e => {
    if (!kf || e.target.value === '') return;
    let v = +e.target.value; if (!isFinite(v)) return;
    kf.anim[field] = clamp(v, min, max);
    if (after) after();
    kfPause(); kfRefresh(); kfCommitSoon(field);
  });
  numField('kfDelay', 'delay', 0, 60);
  numField('kfDur', 'dur', 0.2, 120, () => {
    // keep every keyframe inside the length
    const a = kf.anim, last = Math.max(0, ...KF_PROPS.map(d => a.p[d.k] && a.p[d.k].k.length ? a.p[d.k].k[a.p[d.k].k.length - 1].t : 0));
    if (a.dur < last) a.dur = last;
    kf.head = Math.min(kf.head, a.dur);
  });
  numField('kfPersp', 'persp', 50, 5000);
  $('kfOrigin').addEventListener('change', e => { if (!kf) return; kf.anim.origin = e.target.value; kfEdited('origin'); });
  $('kfLoop').onclick = () => { if (!kf) return; kf.anim.iter = kf.anim.iter === 'infinite' ? '1' : 'infinite'; kfEdited('iter'); flash(kf.anim.iter === 'infinite' ? 'Loop ON — repeats forever' : 'Loop OFF — plays once', 2200); };
  $('kfToggleStop').addEventListener('change', e => { if (!kf) return; kf.anim.toggle = e.target.checked; kfEdited('toggle'); });
  $('kfBack').addEventListener('change', e => { if (!kf) return; kf.anim.hideBack = e.target.checked; kfEdited('back'); });
  [['kfIter', 'iter'], ['kfDir', 'dir']].forEach(([id, field]) => {
    document.querySelectorAll('#' + id + ' button').forEach(b => b.addEventListener('click', () => {
      if (!kf) return;
      kf.anim[field] = b.dataset.v;
      kfEdited(field);
    }));
  });
  document.querySelectorAll('#kfTrig button').forEach(b => b.addEventListener('click', () => {
    if (!kf) return;
    kf.anim.trig.mode = b.dataset.v;
    if (b.dataset.v === 'other' && !kf.anim.trig.id) kf.pick = true;
    kfEdited('trig');
  }));
  $('kfPickBtn').onclick = () => { if (!kf) return; kf.pick = !kf.pick; kfRefreshSetup(); };

  // called when the user taps an element in the preview while "pick button" is active
  function kfPicked(elId) {
    if (!kf) return;
    const own = kf.elId;
    kf.pick = false;
    if (elId === own || elId === 0) { flash('Pick a different element'); post({ type: 'select', id: own }); kfRefreshSetup(); return; }
    let domId = '';
    mutate((doc, list) => {
      const t = list[elId]; if (!t) return false;
      if (!t.id) {
        let n = 1; while (doc.getElementById('mk-btn-' + n)) n++;
        t.id = 'mk-btn-' + n;
      }
      domId = t.id;
    }, { key: 'kf:pick' });
    if (domId) { kf.anim.trig.mode = 'other'; kf.anim.trig.id = domId; kfCommit('trig'); }
    post({ type: 'select', id: own });
    kfRefresh();
  }

  $('kfRemove').onclick = () => {
    if (!kf) return;
    const id = kf.elId;
    kfStopClock();
    if (kf.applied) mutate((doc, list) => { const el = list[id]; if (!el) return false; dropKfClass(doc, el); }, { render: true, keepSelection: true });
    kf.anim = kfNew(kf.anim.name); kf.applied = false; kf.head = 0; kf.scrubbed = false; kf.sel = null;
    kfRefresh();
  };
  $('kfClose').onclick = () => closeKf();
  $('openKf').onclick = () => openKfPanel();

  let kfBuilt = false;
  function openKfPanel() {
    if (selId == null || selId === 0) { flash('Select an element first'); return; }
    const doc = parse(source), el = elementsOf(doc)[selId];
    if (!el) return;
    if (live) setLive(false);
    const store = readKf(doc), cls = [...el.classList].find(c => KF_CLASS.test(c));
    let anim, applied = false;
    if (cls && store[cls]) { anim = store[cls]; applied = true; } else anim = kfNew(kfNextName(doc, store));
    if (!kfOpen) {
      kfPrevView = workspace.dataset.view;
      const pv = document.querySelector('.vbtn[data-view="preview"]');
      if (pv && kfPrevView !== 'preview') pv.click();     // give the preview the whole screen while animating
    }
    if (!kfBuilt) { kfBuildRows(); kfBuilt = true; }
    kfOpen = true;
    const firstAnimated = KF_PROPS.find(d => anim.p[d.k] && anim.p[d.k].k.length);
    kf = { elId: selId, anim, applied, head: 0, scrubbed: false, playing: false, gp: firstAnimated ? firstAnimated.k : 'tx', sel: null, tab: 'time', pick: false, gd: null };
    insp.classList.add('hidden');
    kfPanel.classList.remove('hidden', 'collapsed');
    $('kfTag').textContent = '<' + el.tagName.toLowerCase() + '>';
    document.querySelectorAll('#kfTabs button').forEach(x => x.classList.toggle('on', x.dataset.tab === 'time'));
    $('kfVTime').classList.remove('hidden'); $('kfVGraph').classList.add('hidden'); $('kfVSetup').classList.add('hidden'); $('kfEase').classList.remove('hidden');
    requestAnimationFrame(() => { kfRefresh(); });
  }
  function closeKf() {
    if (!kfOpen) return;
    const id = kf ? kf.elId : null, reset = kf && (kf.scrubbed || kf.playing);
    kfStopClock();
    if (reset && id != null) post({ type: 'kfidle', id });
    kfOpen = false; kf = null;
    kfPanel.classList.add('hidden');
    const v = kfPrevView; kfPrevView = null;
    if (v && workspace.dataset.view !== v) { const b = document.querySelector('.vbtn[data-view="' + v + '"]'); if (b) b.click(); }
    if (selId != null) { insp.classList.remove('hidden'); post({ type: 'select', id: selId }); }
  }

  /* ------------------------------------------------------------------ */
  /*  Layout: view switch + draggable splitter                            */
  /* ------------------------------------------------------------------ */
  document.querySelectorAll('.vbtn').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.vbtn').forEach(x => x.classList.toggle('active', x === b));
    workspace.dataset.view = b.dataset.view;
  }));
  const splitter = $('splitter');
  splitter.addEventListener('pointerdown', e => {
    e.preventDefault();
    splitter.setPointerCapture(e.pointerId);
    frame.style.pointerEvents = 'none';
    const move = ev => {
      const r = workspace.getBoundingClientRect();
      const horizontal = getComputedStyle(workspace).flexDirection === 'row';
      const frac = horizontal ? (ev.clientX - r.left) / r.width : (ev.clientY - r.top) / r.height;
      workspace.style.setProperty('--code-size', Math.min(80, Math.max(15, frac * 100)).toFixed(1) + '%');
    };
    const up = () => {
      frame.style.pointerEvents = '';
      splitter.removeEventListener('pointermove', move);
      splitter.removeEventListener('pointerup', up);
      splitter.removeEventListener('pointercancel', up);
    };
    splitter.addEventListener('pointermove', move);
    splitter.addEventListener('pointerup', up);
    splitter.addEventListener('pointercancel', up);
  });

  /* ------------------------------------------------------------------ */
  /*  Settings + About                                                    */
  /* ------------------------------------------------------------------ */
  const setSheet = $('setSheet'), gearBtn = $('openSettings');
  const store = {
    get(k, d) { try { const v = localStorage.getItem('mk_' + k); return v === null ? d : v; } catch (_) { return d; } },
    set(k, v) { try { localStorage.setItem('mk_' + k, String(v)); } catch (_) {} }
  };
  function applySettings() {
    const fs = +store.get('font', 12.5);
    code.style.fontSize = fs + 'px';
    code.style.whiteSpace = store.get('wrap', '0') === '1' ? 'pre-wrap' : 'pre';
    document.body.classList.toggle('calm', store.get('calm', '0') === '1');
    $('setFont').value = fs; $('setFontOut').textContent = fs + 'px';
    $('setWrap').checked = store.get('wrap', '0') === '1';
    $('setMotion').checked = store.get('calm', '0') === '1';
    document.querySelectorAll('#setView button').forEach(b => b.classList.toggle('on', b.dataset.v === store.get('view', 'split')));
  }
  $('setFont').addEventListener('input', e => { store.set('font', e.target.value); applySettings(); });
  $('setWrap').addEventListener('change', e => { store.set('wrap', e.target.checked ? '1' : '0'); applySettings(); });
  $('setMotion').addEventListener('change', e => { store.set('calm', e.target.checked ? '1' : '0'); applySettings(); });
  document.querySelectorAll('#setView button').forEach(b => b.addEventListener('click', () => {
    store.set('view', b.dataset.v); applySettings();
    const vb = document.querySelector('.vbtn[data-view="' + b.dataset.v + '"]'); if (vb) vb.click();
  }));
  $('setSample').onclick = () => {
    if (!confirm('Replace the current page with the sample page? You can undo with ↶.')) return;
    pushHistory(); restore(INITIAL); setSheetOpen(false);
  };
  $('setDl').onclick = () => $('dlBtn').click();
  function setSheetOpen(on) { setSheet.classList.toggle('hidden', !on); }
  $('closeSet').onclick = () => setSheetOpen(false);
  setSheet.addEventListener('click', e => { if (e.target === setSheet) setSheetOpen(false); });

  // gear tap: spin + glow burst, then the sheet opens
  gearBtn.addEventListener('click', () => {
    gearBtn.classList.remove('pop'); void gearBtn.offsetWidth; gearBtn.classList.add('pop');
    setTimeout(() => {
      let v = ''; try { v = window.MoKnight && MoKnight.getAppVersion ? MoKnight.getAppVersion() : ''; } catch (_) {}
      $('aboutVer').textContent = v ? 'Version ' + v : 'Local workspace';
      setSheetOpen(true);
    }, 420);
  });
  gearBtn.addEventListener('animationend', () => gearBtn.classList.remove('pop'));
  applySettings();
  { const v = store.get('view', 'split'); if (v !== 'split') { const vb = document.querySelector('.vbtn[data-view="' + v + '"]'); if (vb) vb.click(); } }

  /* ------------------------------------------------------------------ */
  /*  AI assistant (sheet)                                                */
  /* ------------------------------------------------------------------ */
  const aiSheet = $('aiSheet');
  $('openAi').onclick = () => aiSheet.classList.remove('hidden');
  $('closeAi').onclick = () => aiSheet.classList.add('hidden');
  aiSheet.addEventListener('click', e => { if (e.target === aiSheet) aiSheet.classList.add('hidden'); });

  const downloadButton = $('downloadModel'), askButton = $('askAi'), promptBox = $('aiPrompt');
  const progressWrap = $('modelProgressWrap'), progressBar = $('modelProgressBar'), progressText = $('modelProgressText');
  const readyText = $('modelReadyText'), aiStatus = $('aiStatus'), aiAnswer = $('aiAnswer'), applyAiAnswer = $('applyAiAnswer');
  const aiAuto = $('aiAuto');
  const TRUNC = '@@MK_TRUNCATED@@';
  const TRUNC_MSG = 'The answer was cut off (too long for the small model), so it was not applied automatically. Try a smaller element or CSS mode.';
  const MODE_HINTS = {
    auto: 'Auto edits the selected element, or the whole page when nothing is selected.',
    element: 'Edits only the element selected in the preview.',
    css: 'Rewrites the page CSS only (good for colors, sizes and spacing).',
    page: 'Rewrites the whole HTML page (small pages only).'
  };
  let latestAiAnswer = '', aiMode = 'auto', aiJob = null, aiBusy = false, pendingApply = null, modelIsReady = false;

  try { aiAuto.checked = localStorage.getItem('mk_ai_auto') !== '0'; } catch (_) {}
  aiAuto.addEventListener('change', () => { try { localStorage.setItem('mk_ai_auto', aiAuto.checked ? '1' : '0'); } catch (_) {} });
  document.querySelectorAll('#aiMode button').forEach(b => b.addEventListener('click', () => {
    aiMode = b.dataset.mode;
    document.querySelectorAll('#aiMode button').forEach(x => x.classList.toggle('on', x === b));
    $('aiModeHint').textContent = MODE_HINTS[aiMode];
  }));

  function setBusy(b) {
    aiBusy = b;
    askButton.textContent = b ? 'Stop' : 'Ask local AI';
    askButton.disabled = b ? false : !modelIsReady;
  }
  function setModelReady() {
    modelIsReady = true;
    readyText.classList.remove('hidden');
    progressWrap.classList.add('hidden');
    downloadButton.textContent = 'Offline model downloaded';
    downloadButton.disabled = true;
    if (!aiBusy) askButton.disabled = false;
    aiStatus.textContent = 'Ready. Describe a change and the assistant edits your page for you, offline.';
  }
  downloadButton.addEventListener('click', () => {
    if (!window.MoKnight) { aiStatus.textContent = 'Open this app on Android to download the model.'; return; }
    downloadButton.disabled = true;
    downloadButton.textContent = 'Starting…';
    MoKnight.downloadModel();
  });

  /* ---- build the request (small model => send only what it needs) ---- */
  function pageForAi() {
    const doc = parse(source);
    ['mk-effects', 'mk-keyframes', 'mk-runtime'].forEach(id => { const t = doc.getElementById(id); if (t) t.remove(); });
    return serialize(doc);
  }
  function userCss(doc) {
    return [...doc.querySelectorAll('style')].filter(s => !/^mk-/.test(s.id)).map(s => s.textContent.trim()).join('\n');
  }
  function outlineOf(list) {
    return list.slice(1, 41).map(e => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (e.classList.length ? '.' + [...e.classList].join('.') : '')).join(', ');
  }
  function buildAiJob(question) {
    const doc = parse(source), list = elementsOf(doc);
    const hasEl = selId != null && selId > 0 && !!list[selId];
    let mode = aiMode;
    if (mode === 'auto') mode = hasEl ? 'element' : (pageForAi().length <= 3000 ? 'page' : 'css');
    const job = { mode, base: source, kfText: (doc.getElementById('mk-keyframes') || {}).textContent || '' };
    if (mode === 'element') {
      if (!hasEl) return { error: 'Tap an element in the preview first, or choose CSS / Page mode.' };
      const outer = list[selId].outerHTML;
      if (outer.length > 2600) return { error: 'That element is too large for the small model. Select a smaller one, or use CSS mode.' };
      job.id = selId;
      job.maxTokens = Math.min(1500, Math.ceil(outer.length / 1.5) + 256);
      job.prompt = 'Edit this HTML element as requested. Keep the same tag and keep all existing attributes, classes and inline styles unless the request needs them changed. ' +
        'Use inline style attributes for visual changes. Reply with ONLY the complete updated element.\n\nELEMENT:\n' + outer + '\n\nREQUEST: ' + question;
    } else if (mode === 'css') {
      const css = userCss(doc);
      if (css.length > 2800) return { error: 'The page CSS is too long for the small model. Select an element and use Element mode.' };
      job.maxTokens = Math.min(1500, Math.ceil(css.length / 1.5) + 400);
      job.prompt = 'Edit the CSS as requested. Keep every existing rule unless the request needs it changed, and add new rules when needed. ' +
        'Reply with ONLY the complete updated CSS (no <style> tags, no explanation).\n\nPAGE ELEMENTS: ' + outlineOf(list) + '\n\nCSS:\n' + css + '\n\nREQUEST: ' + question;
    } else {
      const page = pageForAi();
      if (page.length > 3000) return { error: 'The page is too long for the small model. Use Element or CSS mode.' };
      job.maxTokens = Math.min(1800, Math.ceil(page.length / 1.5) + 400);
      job.prompt = 'Edit this HTML page as requested. Keep all existing text and structure unless the request needs changes. ' +
        'Reply with ONLY the complete updated HTML document.\n\n' + page + '\n\nREQUEST: ' + question;
    }
    return job;
  }

  /* ---- read the answer ---- */
  function extractCode(raw, mode) {
    let t = raw.trim();
    const fenced = /```[a-z]*[ \t]*\n([\s\S]*?)(?:```|$)/i.exec(t);
    if (fenced) t = fenced[1].trim();
    if (mode === 'page') {
      const i = t.search(/<!doctype|<html/i);
      if (i > 0) t = t.slice(i);
      const j = t.toLowerCase().lastIndexOf('</html>');
      if (j >= 0) t = t.slice(0, j + 7);
    } else if (mode === 'element') {
      const i = t.indexOf('<');
      if (i > 0) t = t.slice(i);
    } else {
      t = t.replace(/<\/?style[^>]*>/gi, '').trim();
      const k = t.lastIndexOf('}');
      if (k >= 0) t = t.slice(0, k + 1);
    }
    return t;
  }
  function prepareApply(job, raw, truncated) {
    const text = extractCode(raw, job.mode);
    if (!text) return { ok: false, reason: 'The model returned no code.' };

    if (job.mode === 'element') {
      const tpl = document.createElement('template');
      tpl.innerHTML = text;
      const first = tpl.content.firstElementChild;
      if (!first) return { ok: false, reason: 'No HTML element was found in the response.' };
      return {
        ok: !truncated, reason: truncated ? TRUNC_MSG : '',
        apply: () => {
          mutate((doc, list) => {
            const el = list[job.id]; if (!el || job.id === 0) return false;
            const node = doc.importNode(first, true);
            el.replaceWith(node);
            syncEffectsStyle(doc);
            writeKf(doc, readKf(doc));
            return { select: node };
          }, needsRender);
        }
      };
    }

    if (job.mode === 'css') {
      const open = (text.match(/\{/g) || []).length, close = (text.match(/\}/g) || []).length;
      const balanced = open > 0 && open === close;
      if (!balanced) return { ok: false, reason: truncated ? TRUNC_MSG : 'The CSS in the response is incomplete, so it was not applied.' };
      return {
        ok: !truncated, reason: truncated ? TRUNC_MSG : '',
        apply: () => {
          mutate(doc => {
            let st = [...doc.querySelectorAll('style')].find(x => !/^mk-/.test(x.id));
            if (!st) { st = doc.createElement('style'); doc.head.insertBefore(st, doc.head.firstChild); }
            st.textContent = '\n' + text + '\n';
          }, { render: true, keepSelection: true });
        }
      };
    }

    // page
    if (!/<(html|body|div|h[1-6]|p|main|section|article)\b/i.test(text)) return { ok: false, reason: 'The response does not look like an HTML page.' };
    const d = parse(text), old = parse(source);
    const oldLen = old.body.textContent.replace(/\s+/g, '').length, newLen = d.body.textContent.replace(/\s+/g, '').length;
    const oldN = old.body.querySelectorAll('*').length, newN = d.body.querySelectorAll('*').length;
    let ok = !truncated, reason = truncated ? TRUNC_MSG : '';
    if (ok && ((oldLen >= 20 && newLen < oldLen * 0.4) || (oldN >= 3 && newN < oldN * 0.4))) {
      ok = false; reason = 'The result lost much of the page content, so it was not applied automatically.';
    }
    return {
      ok, reason,
      apply: () => {
        if (job.kfText) {
          const t = d.createElement('style'); t.id = 'mk-keyframes'; t.textContent = job.kfText; d.head.appendChild(t);
          writeKf(d, readKf(d));
        }
        syncRuntime(d);
        syncEffectsStyle(d);
        pushHistory();
        source = serialize(d);
        setCode(source); selId = null; hideInspector(); renderPreview(); notify(); flash('Synced');
      }
    };
  }
  function runApply(prepared) {
    if (prepared.apply() === false) { aiStatus.textContent = 'Could not apply the change.'; return; }
    pendingApply = null;
    applyAiAnswer.classList.add('hidden');
    aiStatus.textContent = '✓ Applied. Use ↶ in the top bar to undo.';
    flash('AI edit applied · ↶ to undo');
    aiSheet.classList.add('hidden');
  }

  askButton.addEventListener('click', () => {
    if (aiBusy) {
      if (window.MoKnight && MoKnight.cancelAi) MoKnight.cancelAi();
      aiStatus.textContent = 'Stopping…';
      return;
    }
    const question = promptBox.value.trim();
    if (!question) { aiStatus.textContent = 'Write what you want changed first.'; return; }
    if (!window.MoKnight) { aiStatus.textContent = 'The local Android bridge is unavailable.'; return; }
    const job = buildAiJob(question);
    if (job.error) { aiStatus.textContent = job.error; return; }
    aiJob = job;
    setBusy(true);
    aiAnswer.classList.add('hidden');
    applyAiAnswer.classList.add('hidden');
    pendingApply = null;
    aiStatus.textContent = 'Working on your phone… this can take a minute. Tap Stop to cancel.';
    MoKnight.askLocalAi(job.prompt, job.maxTokens);
  });
  applyAiAnswer.addEventListener('click', () => { if (pendingApply) runApply(pendingApply); });

  window.MoKnightEditor = {
    // Called by the Android back button. Return true if something was closed.
    handleBack() {
      if (!setSheet.classList.contains('hidden')) { setSheetOpen(false); return true; }
      if (!aiSheet.classList.contains('hidden')) { aiSheet.classList.add('hidden'); return true; }
      if (live) { setLive(false); return true; }
      if (kfOpen) { closeKf(); return true; }
      if (selId != null) { $('actClose').click(); return true; }
      return false;
    },
    onModelProgress(percent, message) {
      progressWrap.classList.remove('hidden');
      progressBar.style.width = percent + '%';
      progressText.textContent = message + (percent > 0 ? ' ' + percent + '%' : '');
      downloadButton.disabled = true;
      downloadButton.textContent = 'Downloading…';
      aiStatus.textContent = 'The model downloads in the background. You can keep editing; a notification shows progress.';
    },
    onModelReady: setModelReady,
    onHtmlSaved(where) { flash('✓ Saved to ' + where, 4500); },
    onHtmlError(msg) { flash('Save failed: ' + msg); },
    onModelError(message) {
      downloadButton.disabled = false;
      downloadButton.textContent = 'Retry download';
      progressWrap.classList.add('hidden');
      aiStatus.textContent = 'Download problem: ' + message;
    },
    onAiResult(answer) {
      setBusy(false);
      let raw = String(answer || '').trim();
      if (/^ERROR:/.test(raw)) { aiJob = null; aiStatus.textContent = raw.replace(/^ERROR:\s*/, ''); return; }
      const truncated = raw.includes(TRUNC);
      raw = raw.replace(TRUNC, '').trim();
      latestAiAnswer = raw;
      aiAnswer.textContent = raw;
      aiAnswer.classList.remove('hidden');
      const job = aiJob; aiJob = null;
      pendingApply = null;
      applyAiAnswer.classList.add('hidden');
      if (!job) return;
      if (source !== job.base) { aiStatus.textContent = 'The page changed while the AI was working, so the result was not applied. Ask again.'; return; }
      const prepared = prepareApply(job, raw, truncated);
      if (prepared.apply && prepared.ok && aiAuto.checked) { runApply(prepared); return; }
      if (prepared.apply) {
        pendingApply = prepared;
        applyAiAnswer.textContent = prepared.ok ? 'Apply result' : 'Apply anyway';
        applyAiAnswer.classList.remove('hidden');
      }
      aiStatus.textContent = prepared.ok ? 'Result ready. Review it, then tap Apply.' : (prepared.reason || 'The result could not be used automatically.');
    },
    onAiError(message) {
      setBusy(false);
      aiJob = null;
      aiStatus.textContent = message;
    }
  };

  /* ---------------- boot ---------------- */
  code.value = source;
  renderPreview();
  notify();
  saveState.textContent = 'Synced locally';
  syncHistoryButtons();
  if (window.MoKnight && MoKnight.modelReady && MoKnight.modelReady()) setModelReady();
  else if (!window.MoKnight) downloadButton.textContent = 'Available in the Android app';
})();
