#include <jni.h>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include <algorithm>
#include "llama.h"

static std::mutex g_lock;
static std::atomic<bool> g_cancel{false};
static llama_model *g_model = nullptr;
static std::string g_model_path;
static bool g_backend_ready = false;

static const int kContext = 4096;       // context window used for every request
static const int kMaxPrompt = 2400;     // tokens allowed for the prompt
static const int kMaxOutput = 1800;     // hard cap for generated tokens

// Returns the text as UTF-8 bytes; Kotlin builds the String (safe for Arabic / emoji).
static jbyteArray make_result(JNIEnv *env, const std::string &value) {
    const jsize size = static_cast<jsize>(value.size());
    jbyteArray array = env->NewByteArray(size);
    if (array != nullptr && size > 0) {
        env->SetByteArrayRegion(array, 0, size, reinterpret_cast<const jbyte *>(value.data()));
    }
    return array;
}

// Drops a half-written multi-byte character at the end (when generation stops mid-character).
static void trim_incomplete_utf8(std::string &s) {
    size_t i = s.size();
    int back = 0;
    while (i > 0 && back < 4 && (static_cast<unsigned char>(s[i - 1]) & 0xC0) == 0x80) {
        --i;
        ++back;
    }
    if (i == 0) return;
    const unsigned char lead = static_cast<unsigned char>(s[i - 1]);
    const int need = lead >= 0xF0 ? 4 : (lead >= 0xE0 ? 3 : (lead >= 0xC0 ? 2 : 1));
    if (need > 1 && (back + 1) < need) s.resize(i - 1);
}

// The model stays loaded between requests, so only the first request pays the loading cost.
static llama_model *ensure_model(const std::string &path) {
    if (!g_backend_ready) {
        llama_backend_init();
        g_backend_ready = true;
    }
    if (g_model != nullptr && g_model_path == path) return g_model;
    if (g_model != nullptr) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = 0; // portable CPU path for Android devices
    g_model = llama_model_load_from_file(path.c_str(), model_params);
    if (g_model != nullptr) g_model_path = path;
    return g_model;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_moknight_studio_LocalLlama_cancelNative(JNIEnv * /* env */, jobject /* thiz */) {
    g_cancel.store(true);
}

extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_moknight_studio_LocalLlama_generateNative(
        JNIEnv *env, jobject /* thiz */, jstring model_path, jstring prompt_text, jint max_tokens) {
    const char *model_chars = env->GetStringUTFChars(model_path, nullptr);
    const char *prompt_chars = env->GetStringUTFChars(prompt_text, nullptr);
    if (model_chars == nullptr || prompt_chars == nullptr) {
        if (model_chars) env->ReleaseStringUTFChars(model_path, model_chars);
        if (prompt_chars) env->ReleaseStringUTFChars(prompt_text, prompt_chars);
        return make_result(env, "ERROR: Could not read model path or prompt.");
    }

    const std::string model_file(model_chars);
    const std::string user_prompt(prompt_chars);
    env->ReleaseStringUTFChars(model_path, model_chars);
    env->ReleaseStringUTFChars(prompt_text, prompt_chars);

    std::lock_guard<std::mutex> guard(g_lock);
    g_cancel.store(false);

    llama_model *model = ensure_model(model_file);
    if (model == nullptr) {
        return make_result(env, "ERROR: Model could not be loaded. Check that the GGUF download completed.");
    }

    const llama_vocab *vocab = llama_model_get_vocab(model);
    const std::string full_prompt =
            "<|im_start|>system\nYou are MoKnight Assistant, a precise HTML, CSS and JavaScript code editor. "
            "Follow the requested output format exactly. When asked to return code, return only the code, "
            "with no explanation and no markdown fences.\n<|im_end|>\n"
            "<|im_start|>user\n" + user_prompt + "\n<|im_end|>\n<|im_start|>assistant\n";

    int32_t token_count = -llama_tokenize(vocab, full_prompt.c_str(),
            static_cast<int32_t>(full_prompt.size()), nullptr, 0, true, true);
    if (token_count <= 0 || token_count > kMaxPrompt) {
        return make_result(env, "ERROR: The request is too long for the small local model. Select a smaller element or use CSS mode.");
    }

    std::vector<llama_token> tokens(static_cast<size_t>(token_count));
    const int32_t actual_count = llama_tokenize(vocab, full_prompt.c_str(),
            static_cast<int32_t>(full_prompt.size()), tokens.data(), token_count, true, true);
    if (actual_count < 0) {
        return make_result(env, "ERROR: Prompt tokenization failed.");
    }

    llama_context_params context_params = llama_context_default_params();
    context_params.n_ctx = kContext;
    context_params.n_batch = std::max<uint32_t>(512, static_cast<uint32_t>(actual_count));
    context_params.n_threads = 4;
    context_params.n_threads_batch = 4;
    llama_context *context = llama_init_from_model(model, context_params);
    if (context == nullptr) {
        return make_result(env, "ERROR: Not enough memory to start the model. Close other apps and try again.");
    }

    llama_batch batch = llama_batch_get_one(tokens.data(), actual_count);
    if (llama_decode(context, batch) != 0) {
        llama_free(context);
        return make_result(env, "ERROR: The model could not process this prompt.");
    }

    llama_sampler *sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_greedy());
    std::string output;
    const int room = kContext - static_cast<int>(actual_count) - 8;
    const int limit = std::max(1, std::min(std::min(static_cast<int>(max_tokens), kMaxOutput), room));
    bool finished = false;
    bool cancelled = false;
    for (int i = 0; i < limit; ++i) {
        if (g_cancel.load()) {
            cancelled = true;
            break;
        }
        const llama_token next = llama_sampler_sample(sampler, context, -1);
        if (llama_vocab_is_eog(vocab, next)) {
            finished = true;
            break;
        }
        char piece[1024];
        const int32_t piece_size = llama_token_to_piece(vocab, next, piece,
                static_cast<int32_t>(sizeof(piece)), 0, true);
        if (piece_size > 0) output.append(piece, static_cast<size_t>(piece_size));
        llama_token token = next;
        batch = llama_batch_get_one(&token, 1);
        if (llama_decode(context, batch) != 0) break;
    }

    llama_sampler_free(sampler);
    llama_free(context);

    if (cancelled) return make_result(env, "ERROR: Stopped.");
    trim_incomplete_utf8(output);
    if (output.empty()) return make_result(env, "ERROR: No response generated.");
    // Marker so the editor knows the answer was cut off by the token limit.
    if (!finished) output += "\n@@MK_TRUNCATED@@";
    return make_result(env, output);
}
