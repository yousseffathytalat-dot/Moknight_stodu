Phase 2 native integration target. CMakeLists.txt and JNI bridge will be added after selecting and testing the llama.cpp Android target.
